"""Autotest du socle : installe l'environnement, vérifie les outils et teste chaque module.

    cd /home/claude/motion_toolkit && python3 selftest.py
Sorties dans selftest/ : planche.png (texte, composition, planche contact), planche_reel.png (test vertical 9:16),
test.mp4, reel.mp4, musique.mp3, sons.wav.
Durée : 1 à 3 minutes selon ce qui doit être installé.
"""
import importlib, os, shutil, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'selftest')
sys.path.insert(0, HERE)

APT = ['fluidsynth', 'fluid-soundfont-gm', 'fonts-noto-core', 'fonts-roboto', 'ghostscript', 'poppler-utils', 'ffmpeg']
PIP = [('cairosvg', 'cairosvg'), ('svgelements', 'svgelements'), ('librosa', 'librosa'), ('uharfbuzz', 'uharfbuzz'),
       ('fontTools', 'fonttools'), ('pretty_midi', 'pretty_midi'), ('PIL', 'pillow'), ('numpy', 'numpy')]


def sh(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True)


def install():
    print('1. Environnement')
    missing = [p for p in APT if sh(f'dpkg -s {p}').returncode != 0]
    if missing:
        print('  apt :', ' '.join(missing))
        r = sh(f'apt-get install -y -q {" ".join(missing)}')
        if r.returncode != 0:
            sh('apt-get update -q'); sh(f'apt-get install -y -q {" ".join(missing)}')
        sh('fc-cache -f')
    for mod, pkg in PIP:
        try:
            importlib.import_module(mod)
        except ImportError:
            print('  pip :', pkg)
            sh(f'pip install -q {pkg} --break-system-packages')
    for tool in ('ffmpeg', 'ffprobe', 'pdftocairo', 'gs', 'fluidsynth'):
        print(f'  {tool:<11}', 'ok' if shutil.which(tool) else 'MANQUANT')
    fams = sh('fc-list : family').stdout
    for fam in ('Roboto', 'Noto Sans Arabic'):
        print(f'  {fam:<17}', 'ok' if fam in fams else 'MANQUANTE')
    print('  banque d\'instruments', 'ok' if os.path.exists('/usr/share/sounds/sf2/FluidR3_GM.sf2') else 'MANQUANTE')


def tests():
    from toolkit import data, timing, camera, compose, render, music, sfx, control, audio, project, text, voix
    os.makedirs(OUT, exist_ok=True)
    C = data.c
    ok = []

    # 2. Texte : arabe, mélange arabe + chiffres, latin avec caractères spéciaux, retour à la ligne, écriture
    def frame_text(t):
        s = text.text(1200, 110, 'كلشي ساهل', 60, C('gris', 900), 'bold')[0]
        s += text.text(1200, 200, 'خلص 800 درهم ف دقيقة وحدة', 32, C('gris', 900), 'bold')[0]
        s += text.text(80, 200, 'Roboto Medium 123 & <ok>', 32, C('gris', 900), 'medium')[0]
        s += text.text(1200, 290, 'هادا نص طويل شوية باش نجربو الرجوع للسطر الجديد بشكل أوتوماتيكي', 26,
                       C('gris', 700), 'regular', max_width=520)[0]
        part, done = text.typed('قهوة قريبة مني', t, 0, 18)
        s += text.text(1200, 420, part + ('' if done else '|'), 28, C('bleu', 600), 'medium')[0]
        return s
    render.still(frame_text, 0.5, f'{OUT}/texte.png')
    ok.append('texte')

    # 2b. Chiffres en arabe : le nombre reste groupé, à droite de l'unité (Bible, section 4)
    for ligne, nombre in (('30 000 درهم', '30 000'), ('2 634 درهم', '2 634'), ('3 أيام', '3'),
                          ('الثمن 1 200,50 درهم', '1 200,50')):
        assert text.is_rtl(ligne), ligne
        runs = text._runs(ligne, True)
        assert ('L', nombre) in runs, (ligne, runs)
        d, _ = text.shape(ligne, 30, 'bold')
        import re as _re
        xs = [float(v) for v in _re.findall(r'translate\(([-0-9.]+),0\)', d)]
        assert xs == sorted(xs) and len(xs) >= 2, (ligne, xs)      # unité à gauche, nombre à droite
    ok.append('chiffres en arabe (30 000 درهم, 2 634 درهم, 3 أيام, 1 200,50)')

    # 3. Composition et caméra : couches de parallaxe et masque (formes neutres de test)
    cam = camera.Camera([(0, (0, 0, 1.0)), (1.0, (200, 0, 1.08))], drift=3)

    def frame_comp(t):
        strip = lambda col, y, h: f'<rect x="-400" y="{y}" width="2400" height="{h}" fill="{col}"/>'
        ticks = lambda col, y: ''.join(f'<rect x="{x}" y="{y}" width="40" height="40" fill="{col}"/>'
                                       for x in range(-400, 2000, 160))
        s = cam.layer(t, strip(C('gris', 200), 120, 160) + ticks(C('gris', 400), 140), 'fond')
        s += cam.layer(t, strip(C('gris', 300), 330, 120) + ticks(C('gris', 500), 350), 'aplats')
        s += cam.layer(t, ticks(C('bleu'), 500) + ticks(C('vert'), 560), 'jeu')
        s += cam.layer(t, ticks(C('rouge'), 640), 'premier_plan')
        a = cam.frame(t, s)
        b = compose.fill_screen(C('jaune', 100)) + text.text(640, 400, 'B', 120, C('gris', 900), 'bold', 'center')[0]
        r = compose.max_radius(640, 360) * timing.ease_in_out(timing.prog(t, 0.3, 0.6))
        return compose.over(a, compose.mask(b, compose.circle_shape(640, 360, r)))
    render.still(frame_comp, 0.55, f'{OUT}/composition.png')
    ok.append('caméra + composition')

    # 4. Musique : 2 mesures en 6/8 (mécanique seulement)
    sc = music.Score(bpm=100, meter='6/8')
    bass = sc.track('basse_acoustique')
    for b in range(2):
        sc.pattern('mains', [b], [0, 1], vel=100)
        for k in range(6):
            sc.hit('castagnettes', b, k / 3, 70 if k % 3 else 95)
        sc.note(bass, 'A2', b, 0, 0.66, 100); sc.note(bass, 'C3', b, 0.66, 0.34, 90); sc.note(bass, 'E3', b, 1, 1, 95)
    sc.render(f'{OUT}/musique.mp3')
    g = sc.grid()
    st = music.structure(30, 100, '6/8')
    ok.append(f"musique ({g['bpm']} BPM, {g['meter']}, {len(g['beats'])} pulsations ; structure 30 s → {st['bars']} mesures)")

    # 5. Sons
    tl = sfx.Timeline(2.0)
    tl.add(sfx.pop(), 0.2); tl.add(sfx.swoosh(), 0.6); tl.add(sfx.ding(), 1.1)
    for k in range(6):
        tl.add(sfx.click(seed=k), 1.5 + k / 18)
    tl.write(f'{OUT}/sons.wav')
    ok.append('sons')

    # 6. Rendu parallèle + mixage + contrôles
    n = render.frames(frame_comp, 2.0, f'{OUT}/images', size=(640, 360), verbose=False)
    render.video(f'{OUT}/images', f'{OUT}/muet.mp4')
    audio.mix(f'{OUT}/muet.mp4', f'{OUT}/test.mp4', music=f'{OUT}/musique.mp3', sfx=f'{OUT}/sons.wav', fade_video=0.3)
    control.contact_sheet(f'{OUT}/test.mp4', f'{OUT}/planche_contact.png', every=5, width=240)
    res, issues = control.report(f'{OUT}/test.mp4', target_duration=2.0)
    shutil.rmtree(f'{OUT}/images'); os.remove(f'{OUT}/muet.mp4')
    ok.append(f'rendu ({n} images) + mixage ({res["lufs"]} LUFS) + contrôles ({len(issues)} alerte(s))')

    # 7. Projet : découpage calé sur la grille
    p = project.Project(f'{OUT}/projet.json')
    p.data['plans'] = [dict(id='P1', duree=0.9), dict(id='P2', duree=1.1)]
    p.timeline(grid=g, snap='beats')
    p.save()
    ok.append('projet (' + ', '.join(f"{x['id']} {x['debut']}→{x['fin']}" for x in p.data['plans']) + ')')

    # 8. Reel vertical 9:16 : rendu, voix préparée, enveloppe de la musique, mixage, contrôles au format
    import numpy as np
    sr = voix.SR
    t = np.arange(int(1.6 * sr)) / sr
    ph = 2 * np.pi * np.cumsum(140 + 20 * np.sin(2 * np.pi * 0.7 * t)) / sr
    y = sum(np.sin(k * ph) / k ** 1.2 for k in range(1, 25)) * (0.5 + 0.5 * np.sin(2 * np.pi * 4 * t)) ** 2
    y = np.concatenate([np.zeros(int(0.2 * sr)), y, np.zeros(int(0.2 * sr))]) * 0.2
    voix.ecrire(f'{OUT}/p1a_test.wav', y.astype(np.float32))
    prep = voix.preparer(f'{OUT}/p1a_test.wav', f'{OUT}/p1a_prep.wav')
    pl = voix.placer({'p1a_test': f'{OUT}/p1a_prep.wav'}, {'p1a_test': 0.3}, f'{OUT}/voix.wav', duree=3.0)
    sc2 = music.Score(bpm=66, meter='3/4')
    pno = sc2.track('piano')
    for b in range(2):
        sc2.chord(pno, ['A3', 'C4', 'E4'], b, 0, 3, 80)
    sc2.render(f'{OUT}/musique_reel.wav', duration=3.0)
    audio.duck_music(f'{OUT}/musique_reel.wav', f'{OUT}/musique_reel_att.wav', pl, 3.0)
    intel, _ = voix.intelligibilite(f'{OUT}/voix.wav', f'{OUT}/musique_reel_att.wav', pl)
    x0, y0, x1, y1 = data.safe_box()

    def frame_reel(tt):
        s_ = compose.fill_screen(C('gris', 50), size=(720, 1280))
        s_ += f'<rect x="{x0}" y="{y0}" width="{x1 - x0}" height="{y1 - y0}" fill="none" stroke="{C("gris", 300)}" stroke-dasharray="8 8"/>'
        s_ += text.text(680, 260, 'كلشي ساهل', 56, C('gris', 900), 'bold')[0]
        s_ += text.montant(680, 330, '2 634', 'درهم', 40, C('bleu', 600))[0]
        r = 60 + 10 * np.sin(tt * 3)
        s_ += f'<circle cx="360" cy="640" r="{r:.1f}" fill="{C("vert")}"/>'
        return s_
    render.frames(frame_reel, 3.0, f'{OUT}/images_reel', format='9:16', size=(360, 640), verbose=False)
    render.video(f'{OUT}/images_reel', f'{OUT}/reel_muet.mp4')
    audio.mix(f'{OUT}/reel_muet.mp4', f'{OUT}/reel.mp4', music=f'{OUT}/musique_reel.wav', voice=f'{OUT}/voix.wav',
              placement=pl, fade_video=0.3)
    control.contact_sheet(f'{OUT}/reel.mp4', f'{OUT}/planche_reel.png', every=10)
    _, mx = control.deplacement_global(f'{OUT}/reel.mp4', 0.0, 2.5)
    shutil.rmtree(f'{OUT}/images_reel'); os.remove(f'{OUT}/reel_muet.mp4')
    w_, h_ = control.video_size(f'{OUT}/reel.mp4')
    ok.append(f"reel {w_}×{h_} : voix {prep['apres']['lufs']} LUFS, voix/musique {intel.get('p1a_test')} dB "
              f"(1-5 kHz), déplacement global {mx:.1f} px")

    # 9. Sons d'appoint
    for gen in (sfx.froissement, sfx.vibration, sfx.sonnerie, sfx.tampon, sfx.boom, sfx.impact, sfx.nappe, sfx.tictac):
        assert len(gen()) > 0
    ok.append('sons d\'appoint (froissement, vibration, sonnerie, tampon, boom, impact, nappe, tic-tac)')

    # planche de synthèse
    from PIL import Image
    a, b, c = (Image.open(f'{OUT}/{f}') for f in ('texte.png', 'composition.png', 'planche_contact.png'))
    a.thumbnail((640, 360)); b.thumbnail((640, 360)); c.thumbnail((1280, 400))
    out = Image.new('RGB', (1280, 360 + c.height + 10), 'white')
    out.paste(a, (0, 0)); out.paste(b, (640, 0)); out.paste(c, (0, 370))
    out.save(f'{OUT}/planche.png')
    print('2. Tests')
    for x in ok:
        print('  ok –', x)
    for x in issues:
        print('  alerte –', x)
    print('Socle prêt. Planche de contrôle : selftest/planche.png')


if __name__ == '__main__':
    install()
    tests()
