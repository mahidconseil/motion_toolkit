"""Autotest du socle : installe l'environnement, vérifie les outils et teste chaque module.

    cd /home/claude/motion_toolkit && python3 selftest.py
Sorties dans selftest/ : planche.png (texte, composition, planche contact), test.mp4, musique.mp3, sons.wav.
Durée : 1 à 3 minutes selon ce qui doit être installé.
"""
import importlib, os, shutil, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'selftest')
sys.path.insert(0, HERE)

APT = ['fluidsynth', 'fluid-soundfont-gm', 'fonts-noto-core', 'fonts-roboto', 'ghostscript', 'poppler-utils', 'ffmpeg']
PIP = [('cairosvg', 'cairosvg'), ('svgelements', 'svgelements'), ('librosa', 'librosa'), ('uharfbuzz', 'uharfbuzz'),
       ('fontTools', 'fonttools'), ('pretty_midi', 'pretty_midi'), ('PIL', 'pillow'), ('numpy', 'numpy')]


def sh(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True)


def install():
    print('1. Environnement')
    missing = [p for p in APT if sh(f'dpkg -s {p}').returncode != 0]
    if missing:
        print('  apt :', ' '.join(missing))
        r = sh(f'apt-get install -y -q {" ".join(missing)}')
        if r.returncode != 0:
            sh('apt-get update -q'); sh(f'apt-get install -y -q {" ".join(missing)}')
        sh('fc-cache -f')
    for mod, pkg in PIP:
        try:
            importlib.import_module(mod)
        except ImportError:
            print('  pip :', pkg)
            sh(f'pip install -q {pkg} --break-system-packages')
    for tool in ('ffmpeg', 'ffprobe', 'pdftocairo', 'gs', 'fluidsynth'):
        print(f'  {tool:<11}', 'ok' if shutil.which(tool) else 'MANQUANT')
    fams = sh('fc-list : family').stdout
    for fam in ('Roboto', 'Noto Sans Arabic'):
        print(f'  {fam:<17}', 'ok' if fam in fams else 'MANQUANTE')
    print('  banque d\'instruments', 'ok' if os.path.exists('/usr/share/sounds/sf2/FluidR3_GM.sf2') else 'MANQUANTE')


def tests():
    from toolkit import data, timing, camera, compose, render, music, sfx, control, audio, project, text
    os.makedirs(OUT, exist_ok=True)
    C = data.c
    ok = []

    # 2. Texte : arabe, mélange arabe + chiffres, latin avec caractères spéciaux, retour à la ligne, écriture
    def frame_text(t):
        s = text.text(1200, 110, 'كلشي ساهل', 60, C('gris', 900), 'bold')[0]
        s += text.text(1200, 200, 'خلص 800 درهم ف دقيقة وحدة', 32, C('gris', 900), 'bold')[0]
        s += text.text(80, 200, 'Roboto Medium 123 & <ok>', 32, C('gris', 900), 'medium')[0]
        s += text.text(1200, 290, 'هادا نص طويل شوية باش نجربو الرجوع للسطر الجديد بشكل أوتوماتيكي', 26,
                       C('gris', 700), 'regular', max_width=520)[0]
        part, done = text.typed('قهوة قريبة مني', t, 0, 18)
        s += text.text(1200, 420, part + ('' if done else '|'), 28, C('bleu', 600), 'medium')[0]
        return s
    render.still(frame_text, 0.5, f'{OUT}/texte.png')
    ok.append('texte')

    # 3. Composition et caméra : couches de parallaxe et masque (formes neutres de test)
    cam = camera.Camera([(0, (0, 0, 1.0)), (1.0, (200, 0, 1.08))], drift=3)

    def frame_comp(t):
        strip = lambda col, y, h: f'<rect x="-400" y="{y}" width="2400" height="{h}" fill="{col}"/>'
        ticks = lambda col, y: ''.join(f'<rect x="{x}" y="{y}" width="40" height="40" fill="{col}"/>'
                                       for x in range(-400, 2000, 160))
        s = cam.layer(t, strip(C('gris', 200), 120, 160) + ticks(C('gris', 400), 140), 'fond')
        s += cam.layer(t, strip(C('gris', 300), 330, 120) + ticks(C('gris', 500), 350), 'aplats')
        s += cam.layer(t, ticks(C('bleu'), 500) + ticks(C('vert'), 560), 'jeu')
        s += cam.layer(t, ticks(C('rouge'), 640), 'premier_plan')
        a = cam.frame(t, s)
        b = compose.fill_screen(C('jaune', 100)) + text.text(640, 400, 'B', 120, C('gris', 900), 'bold', 'center')[0]
        r = compose.max_radius(640, 360) * timing.ease_in_out(timing.prog(t, 0.3, 0.6))
        return compose.over(a, compose.mask(b, compose.circle_shape(640, 360, r)))
    render.still(frame_comp, 0.55, f'{OUT}/composition.png')
    ok.append('caméra + composition')

    # 4. Musique : 2 mesures en 6/8 (mécanique seulement)
    sc = music.Score(bpm=100, meter='6/8')
    bass = sc.track('basse_acoustique')
    for b in range(2):
        sc.pattern('mains', [b], [0, 1], vel=100)
        for k in range(6):
            sc.hit('castagnettes', b, k / 3, 70 if k % 3 else 95)
        sc.note(bass, 'A2', b, 0, 0.66, 100); sc.note(bass, 'C3', b, 0.66, 0.34, 90); sc.note(bass, 'E3', b, 1, 1, 95)
    sc.render(f'{OUT}/musique.mp3')
    g = sc.grid()
    st = music.structure(30, 100, '6/8')
    ok.append(f"musique ({g['bpm']} BPM, {g['meter']}, {len(g['beats'])} pulsations ; structure 30 s → {st['bars']} mesures)")

    # 5. Sons
    tl = sfx.Timeline(2.0)
    tl.add(sfx.pop(), 0.2); tl.add(sfx.swoosh(), 0.6); tl.add(sfx.ding(), 1.1)
    for k in range(6):
        tl.add(sfx.click(seed=k), 1.5 + k / 18)
    tl.write(f'{OUT}/sons.wav')
    ok.append('sons')

    # 6. Rendu parallèle + mixage + contrôles
    n = render.frames(frame_comp, 2.0, f'{OUT}/images', size=(640, 360), verbose=False)
    render.video(f'{OUT}/images', f'{OUT}/muet.mp4')
    audio.mix(f'{OUT}/muet.mp4', f'{OUT}/test.mp4', music=f'{OUT}/musique.mp3', sfx=f'{OUT}/sons.wav', fade_video=0.3)
    control.contact_sheet(f'{OUT}/test.mp4', f'{OUT}/planche_contact.png', every=5, width=240)
    res, issues = control.report(f'{OUT}/test.mp4', target_duration=2.0)
    shutil.rmtree(f'{OUT}/images'); os.remove(f'{OUT}/muet.mp4')
    ok.append(f'rendu ({n} images) + mixage ({res["lufs"]} LUFS) + contrôles ({len(issues)} alerte(s))')

    # 7. Projet : découpage calé sur la grille
    p = project.Project(f'{OUT}/projet.json')
    p.data['plans'] = [dict(id='P1', duree=0.9), dict(id='P2', duree=1.1)]
    p.timeline(grid=g, snap='beats')
    p.save()
    ok.append('projet (' + ', '.join(f"{x['id']} {x['debut']}→{x['fin']}" for x in p.data['plans']) + ')')

    # planche de synthèse
    from PIL import Image
    a, b, c = (Image.open(f'{OUT}/{f}') for f in ('texte.png', 'composition.png', 'planche_contact.png'))
    a.thumbnail((640, 360)); b.thumbnail((640, 360)); c.thumbnail((1280, 400))
    out = Image.new('RGB', (1280, 360 + c.height + 10), 'white')
    out.paste(a, (0, 0)); out.paste(b, (640, 0)); out.paste(c, (0, 370))
    out.save(f'{OUT}/planche.png')
    print('2. Tests')
    for x in ok:
        print('  ok –', x)
    for x in issues:
        print('  alerte –', x)
    print('Socle prêt. Planche de contrôle : selftest/planche.png')


if __name__ == '__main__':
    install()
    tests()
