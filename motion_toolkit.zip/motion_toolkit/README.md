# motion_toolkit 2.2 – socle de plomberie

Implémente la plomberie de la « Bible de style – Motion design éditorial » (section 10). Il calcule, contrôle
et assemble ; il ne contient aucun décor, objet, transition ni morceau de musique : ceux-ci s'écrivent
pour chaque film selon la spec de la section 10.

Démarrage : `cd /home/claude/motion_toolkit && python3 selftest.py`

| Module | Rôle |
| --- | --- |
| `data` | palette Google, carnations (dont méditerranéen mat), cheveux, préréglages, formats, zones sûres du Reel, cadre de couverture 3:4, vitesses de parallaxe |
| `timing` | courbes, progressions, images clés, conversions s ↔ images, cascades |
| `svg` | échappement, identifiants uniques, groupes transformés, document de rendu, tracé progressif |
| `text` | arabe et latin mis en forme en formes vectorielles, bidirectionnel (nombres à espaces groupés), montants nombre + unité, retour à la ligne, écriture lettre par lettre |
| `camera` | couches de parallaxe, travellings, zooms, dérive permanente |
| `compose` | masques, superposition, décalage, opacité, formes de masque, traînées de vitesse |
| `kits` | import (meilleure source entre .ai et .eps), calibration, épaule automatique, traits fins, rapport de couleurs, rapprochement palette |
| `articule` | rig articulé propriétaire (SVG par vue + manifest + poses + cycles, ex. Kabour) : articulations pilotées, poses par zone avec transitions, cycles de marche avec ourlet, expressions, clignements, regard, parole d'après le volume et le texte en darija, placement |
| `rig` | personnage cut-out (têtes, bras, miroir, parole, clignement, respiration, placement, mains), traits fins, chevelure arrière, échelle de tête, bouche en trait, position d'une main à l'écran |
| `render` | image fixe et calcul parallèle au format du film (16:9, 9:16, 1:1), encodage, estimation du temps de calcul étalonnée |
| `audio` | grille d'une musique fournie, volume, enveloppe de gain de la musique sous les répliques, mixage final (−14 LUFS, deux passes, recalage) |
| `voix` | mesure des répliques, préparation (chaîne de la Bible, −16 LUFS, téléphone), placement, courbes de bouche, intelligibilité 1-5 kHz |
| `music` | écriture MIDI en mesures et pulsations (4/4, 3/4, 6/8, 12/8), instruments et percussions nommés, gammes, structure du film, insertion de mesures, rendu normalisé coupé à la durée exacte, grille exacte |
| `sfx` | synthèse (tons, bruit, filtres, enveloppes), points de départ pop, clic, swoosh, ding, froissement, vibration, sonnerie, tampon, boom, impact, nappe, tic-tac, ligne de temps |
| `control` | planches contact, bandes et storyboard au format du film, zoom, synchro (ligne de temps ou détection), gels et images vides hors passages voulus, image fixe garantie (corrélation de phase), volume, rapport |
| `reference` | analyse d'une vidéo de référence |
| `project` | projet.json, découpage calé sur la grille musicale, plan courant |

## Nouveautés 2.1 (retours de production « عرس »)

- Nombres en arabe : « 30 000 درهم » n'est plus coupé ni inversé ; `text.montant()` compose nombre et unité.
- Format vertical : `render.still/frames(..., format='9:16')` ; zones sûres et cadre de couverture dans `data`.
- Atténuation de la musique par enveloppe de gain (−10 dB, −15 dB sous la première réplique) ; compresseur en option.
- Nouveau module `voix` ; critère d'intelligibilité +10 dB dans la bande 1-5 kHz.
- Rig : traits fins, chevelure arrière, échelle de tête, bouche en trait, `main_ecran`.
- Kits : choix automatique de la meilleure source ; épaule détectée selon la position de la main.
- Contrôles au format du film, passages voulus, image fixe garantie, synchro sur la ligne de temps.
- Musique : normalisation en deux passes, coupe exacte, `insert_bars` ; recalage de ~30 ms après normalisation
  (la normalisation décalait l'audio de presque une image).

## Nouveautés 2.2

- Module `articule` : pilote des rigs articulés livrés en SVG + manifest + poses + cycles (personnage de marque
  Kabour). Les fichiers du personnage restent dans le dépôt privé des kits, jamais dans ce dépôt public.
