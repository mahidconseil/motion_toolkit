# motion_toolkit 2.0 – socle de plomberie

Implémente la plomberie de la « Bible de style – Motion design éditorial » (section 10). Il calcule, contrôle
et assemble ; il ne contient aucun décor, objet, transition ni morceau de musique : ceux-ci s'écrivent
pour chaque film selon la spec de la section 10.

Démarrage : `cd /home/claude/motion_toolkit && python3 selftest.py`

| Module | Rôle |
| --- | --- |
| `data` | palette Google, carnations, cheveux, préréglages, formats, vitesses de parallaxe |
| `timing` | courbes, progressions, images clés, conversions s ↔ images, cascades |
| `svg` | échappement, identifiants uniques, groupes transformés, document de rendu, tracé progressif |
| `text` | arabe et latin mis en forme en formes vectorielles, bidirectionnel, retour à la ligne, écriture lettre par lettre |
| `camera` | couches de parallaxe, travellings, zooms, dérive permanente |
| `compose` | masques, superposition, décalage, opacité, formes de masque, traînées de vitesse |
| `kits` | import et calibration des kits personnage, rapport de couleurs, rapprochement palette |
| `rig` | personnage cut-out (têtes, bras, miroir, parole, clignement, respiration, placement, mains) |
| `render` | image fixe, calcul parallèle, encodage, estimation du temps de calcul |
| `audio` | grille d'une musique fournie, phrases de voix, courbe de bouche, volume, mixage final |
| `music` | écriture MIDI en mesures et pulsations, instruments et percussions nommés, gammes, structure du film, rendu, grille exacte |
| `sfx` | synthèse (tons, bruit, filtres, enveloppes), points de départ pop/click/swoosh/ding, ligne de temps |
| `control` | planches contact, bandes, zoom, storyboard, synchro, gels, images vides, volume, rapport |
| `reference` | analyse d'une vidéo de référence |
| `project` | projet.json, découpage calé sur la grille musicale, plan courant |
