"""Audio : grille d'une musique fournie, phrases de voix off, courbe de bouche, volume, mixage final (Bible, sections 8 et 10)."""
import json, os

import numpy as np

FPS = 25


def _load(path, sr=22050):
    import librosa
    y, sr = librosa.load(path, sr=sr, mono=True)
    return y, sr


def analyze(path, out_json='projet/grille.json', sheet_png='projet/grille.png', top=12):
    """Grille de synchronisation d'une musique : tempo, temps, mesures, attaques fortes, énergie, sections."""
    import librosa
    y, sr = _load(path)
    dur = len(y) / sr
    tempo, beats = librosa.beat.beat_track(y=y, sr=sr)
    tempo = float(np.atleast_1d(tempo)[0])
    bt = librosa.frames_to_time(beats, sr=sr)
    env = librosa.onset.onset_strength(y=y, sr=sr)
    # premier temps de mesure : le temps (parmi les 4 premiers) dont la série 1/4 a la plus forte attaque moyenne
    bstr = env[np.minimum(beats, len(env) - 1)] if len(beats) else np.array([])
    off = int(np.argmax([bstr[k::4].mean() if len(bstr[k::4]) else 0 for k in range(4)])) if len(bstr) >= 4 else 0
    bars = bt[off::4]
    on = librosa.onset.onset_detect(onset_envelope=env, sr=sr)
    strong = on[np.argsort(env[on])[::-1][:top]] if len(on) else np.array([], int)
    strong_t = sorted(float(v) for v in librosa.frames_to_time(strong, sr=sr))
    hop = int(sr * 0.1)
    rms = librosa.feature.rms(y=y, frame_length=hop * 2, hop_length=hop)[0]
    db = 20 * np.log10(rms + 1e-9)
    # sections : ruptures d'énergie lissée sur 2 s
    sm = np.convolve(db, np.ones(20) / 20, mode='same')
    jumps = np.abs(np.diff(sm))
    cand = np.argsort(jumps)[::-1]
    sections = []
    for c in cand:
        tt = c * 0.1
        if jumps[c] < 1.5 or len(sections) >= 6:
            break
        if all(abs(tt - s) > 4 for s in sections) and 2 < tt < dur - 2:
            sections.append(round(tt, 2))
    grid = dict(
        file=os.path.basename(path), duration=round(dur, 3), fps=FPS, tempo=round(tempo, 2),
        beats=[round(float(v), 3) for v in bt], beat_frames=[int(round(v * FPS)) for v in bt],
        bars=[round(float(v), 3) for v in bars], strong_onsets=[round(v, 3) for v in strong_t],
        sections=sorted(sections), energy_db_100ms=[round(float(v), 1) for v in db],
    )
    if out_json:
        os.makedirs(os.path.dirname(out_json) or '.', exist_ok=True)
        with open(out_json, 'w') as f:
            json.dump(grid, f)
    if sheet_png:
        grid_sheet(grid, sheet_png)
    return grid


def grid_sheet(grid, out_png, width=1600, height=420):
    """Planche visuelle de la grille : énergie, temps, mesures, attaques fortes, sections."""
    import cairosvg
    dur, db = grid['duration'], np.array(grid['energy_db_100ms'])
    X = lambda t: 40 + (width - 80) * t / dur
    lo, hi = float(db.min()), float(db.max())
    Y = lambda v: height - 60 - (height - 140) * (v - lo) / max(1e-6, hi - lo)
    pts = ' '.join(f'{X(i * .1):.1f},{Y(v):.1f}' for i, v in enumerate(db))
    s = f'<rect width="{width}" height="{height}" fill="#F7F6FA"/>'
    for t in grid['beats']:
        s += f'<line x1="{X(t):.1f}" y1="60" x2="{X(t):.1f}" y2="{height - 60}" stroke="#D2CEDD" stroke-width="1"/>'
    for t in grid['bars']:
        s += f'<line x1="{X(t):.1f}" y1="50" x2="{X(t):.1f}" y2="{height - 60}" stroke="#8E88A3" stroke-width="1.6"/>'
    for t in grid['sections']:
        s += f'<line x1="{X(t):.1f}" y1="30" x2="{X(t):.1f}" y2="{height - 40}" stroke="#13B48C" stroke-width="3"/>'
    s += f'<polyline points="{pts}" fill="none" stroke="#332B2B" stroke-width="1.6"/>'
    for t in grid['strong_onsets']:
        s += f'<circle cx="{X(t):.1f}" cy="45" r="7" fill="#BB0102"/>'
    for k in range(int(dur) + 1):
        s += f'<text x="{X(k):.1f}" y="{height - 30}" font-size="13" text-anchor="middle" font-family="DejaVu Sans" fill="#6E6A7A">{k}s</text>'
    s += (f'<text x="40" y="24" font-size="16" font-family="DejaVu Sans" fill="#332B2B">{grid["file"]} — {grid["tempo"]} BPM — '
          f'{grid["duration"]} s — traits fins : temps, traits gris : mesures, vert : sections, points rouges : attaques fortes</text>')
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}">{s}</svg>'
    os.makedirs(os.path.dirname(out_png) or '.', exist_ok=True)
    cairosvg.svg2png(bytestring=svg.encode(), write_to=out_png)
    return out_png


def snap(t, grid, to='beats'):
    """Ramène un instant sur le temps (ou la mesure) le plus proche de la grille."""
    pts = grid[to]
    return min(pts, key=lambda v: abs(v - t)) if pts else t


def segments(path, top_db=35, min_gap=0.25):
    """Phrases d'une voix off : liste de (début, fin) en secondes, détection des silences."""
    import librosa
    y, sr = _load(path)
    iv = librosa.effects.split(y, top_db=top_db)
    segs = []
    for a, b in iv:
        a, b = a / sr, b / sr
        if segs and a - segs[-1][1] < min_gap:
            segs[-1] = (segs[-1][0], b)
        else:
            segs.append((a, b))
    return [(round(float(a), 3), round(float(b), 3)) for a, b in segs]


def mouth_curve(path, fps=FPS, floor_db=-45, smooth=2):
    """Ouverture de bouche 0..1 image par image d'après le volume d'une voix (synchro labiale simple)."""
    import librosa
    y, sr = _load(path)
    hop = int(sr / fps)
    rms = librosa.feature.rms(y=y, frame_length=hop * 2, hop_length=hop)[0]
    db = 20 * np.log10(rms + 1e-9)
    peak = np.percentile(db, 98)
    v = np.clip((db - floor_db) / max(1e-6, peak - floor_db), 0, 1)
    if smooth > 1:
        v = np.convolve(v, np.ones(smooth) / smooth, mode='same')
    return [round(float(x), 3) for x in v]


def loudness(path):
    """Volume intégré (LUFS) mesuré par ffmpeg (ebur128)."""
    import re, subprocess
    r = subprocess.run(['ffmpeg', '-nostats', '-i', path, '-filter_complex', 'ebur128', '-f', 'null', '-'],
                       capture_output=True, text=True)
    m = re.findall(r'I:\s+(-?[0-9.]+) LUFS', r.stderr)
    return float(m[-1]) if m else None


def mix(video_in, out_mp4, music=None, voice=None, sfx=None, voice_offset=0.0, music_offset=0.0,
        sfx_gain_db=-6.0, duck=True, fade_out=1.0, target_lufs=-14.0, fade_video=0.5, fade_color='white'):
    """Bande-son finale sur la vidéo : musique (atténuée de ~10 dB sous la voix), voix, sons (6 dB sous la musique),
    normalisation −14 LUFS / −1 dBTP, fondu audio de sortie, fondu vidéo final (blanc par défaut)."""
    import subprocess
    from .render import duration_of
    d = duration_of(video_in)
    inputs, filt, mix_in = ['-i', video_in], [], []
    idx = 1
    if music:
        inputs += ['-ss', str(music_offset), '-i', music]
        filt.append(f'[{idx}:a]aformat=channel_layouts=stereo,apad,atrim=0:{d}[m]'); idx += 1
    if voice:
        inputs += ['-i', voice]
        ms = int(voice_offset * 1000)
        filt.append(f'[{idx}:a]adelay={ms}|{ms},aformat=channel_layouts=stereo,apad,atrim=0:{d}[v]'); idx += 1
    if sfx:
        inputs += ['-i', sfx]
        filt.append(f'[{idx}:a]aformat=channel_layouts=stereo,volume={sfx_gain_db}dB,apad,atrim=0:{d}[s]'); idx += 1
    if music and voice and duck:
        filt.append('[v]asplit=2[v1][v2]')
        filt.append('[m][v1]sidechaincompress=threshold=0.03:ratio=6:attack=40:release=300[md]')
        mix_in = ['md', 'v2']
    else:
        mix_in = [x for x, ok in (('m', music), ('v', voice)) if ok]
    if sfx:
        mix_in.append('s')
    vf = 'null'
    if fade_video:
        vf = f'fade=t=out:st={max(0, d - fade_video):.3f}:d={fade_video}:color={fade_color}'
    if not mix_in:
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', video_in, '-vf', vf, '-c:v', 'libx264', '-crf', '18',
                        '-pix_fmt', 'yuv420p', out_mp4], check=True)
        return out_mp4
    filt.append(''.join(f'[{x}]' for x in mix_in) + f'amix=inputs={len(mix_in)}:normalize=0[mx]')
    # normalisation en deux passes (mesure puis correction linéaire), fiable même sur un extrait court
    pre = ';'.join(filt + [f'[mx]afade=t=out:st={max(0, d - fade_out):.3f}:d={fade_out},loudnorm=I={target_lufs}:TP=-1:LRA=11:print_format=json[aout]'])
    r = subprocess.run(['ffmpeg', '-hide_banner', *inputs, '-filter_complex', pre, '-map', '[aout]', '-t', f'{d:.3f}',
                       '-f', 'null', '-'], capture_output=True, text=True)
    import json as _json, re as _re
    m = _re.search(r'\{[^{}]*"input_i"[^{}]*\}', r.stderr)
    norm = f'loudnorm=I={target_lufs}:TP=-1:LRA=11'
    if m:
        js = _json.loads(m.group(0))
        norm += (f":measured_I={js['input_i']}:measured_TP={js['input_tp']}:measured_LRA={js['input_lra']}"
                 f":measured_thresh={js['input_thresh']}:offset={js['target_offset']}:linear=true")
    filt.append(f'[mx]afade=t=out:st={max(0, d - fade_out):.3f}:d={fade_out},{norm}[aout]')
    subprocess.run(['ffmpeg', '-v', 'error', '-y', *inputs, '-filter_complex', ';'.join(filt),
                    '-map', '0:v', '-map', '[aout]', '-vf', vf, '-c:v', 'libx264', '-crf', '18', '-pix_fmt', 'yuv420p',
                    '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-t', f'{d:.3f}', out_mp4], check=True)
    return out_mp4
