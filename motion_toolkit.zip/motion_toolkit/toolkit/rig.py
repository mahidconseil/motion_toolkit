"""Rig cut-out d'un personnage (Bible, sections 3 et 5).

    kit = load_kit("kits/mon_kit.json")          # fichier de calibration (schéma : kits.py)
    pere = Character(kit, {"veste": "#AECBFA", "peau": "#8B4F3A"}, seed=1)   # rôles de couleur → hex
    svg = pere.draw(t, head='inquiet', left=('L3m', 0), right=('L2', 0), talk=0.6)
    svg = pere.place(svg, x=450)                      # en pied, posé sur la ligne de sol

Extensions (kits Freepik) : formes à trait (stroke, sw, srole), chevelure arrière (body.hair_back),
échelle de tête (kit['head_scale'] ou Character(head_scale=…), pour harmoniser deux kits), bouche en trait
(heads[…].mouth_line : la parole ajoute une petite ouverture sombre au lieu d'étirer le trait),
position à l'écran d'une main (main_ecran) pour y poser un objet.
Technique admise : une tête de profil sur un corps de face, pour détourner le regard (Bible, section 3).
"""
import itertools, json, math, os, random

from .timing import damped

_uid = itertools.count(1)
FLOOR_Y = 684   # ligne de sol à 95 % de 720


def load_kit(path):
    with open(path) as f:
        return json.load(f)


def kit_path(name):
    return os.path.join(os.path.dirname(__file__), '..', 'kits', name + '.json')


class Character:
    def __init__(self, kit, colors=None, mirror=False, seed=0, head_scale=None):
        """colors : rôles de couleur → hex (rôles de remplissage et de trait). mirror : regarde vers la gauche.
        seed : décale périodes, phases et clignements pour que deux personnages ne bougent jamais ensemble.
        head_scale : échelle de la tête et de la chevelure (défaut : kit['head_scale'] ou 1)."""
        self.kit, self.colors, self.mirror = kit, dict(colors or {}), mirror
        self.head_scale = head_scale if head_scale is not None else kit.get('head_scale', 1.0)
        self.uid = next(_uid)
        r = random.Random(seed)
        self.p_breath = r.uniform(2.0, 2.3)
        self.p_head = r.uniform(2.4, 2.8)
        self.phase = r.uniform(0, 6.28)
        t, self.blinks = r.uniform(0.3, 1.5), []
        while t < 600:
            self.blinks.append(t)
            t += r.uniform(2.5, 4.0)

    # ---------- dessin des formes
    def _paint(self, shapes, extra=None):
        out = []
        for s in shapes:
            role = s.get('role')
            fill = self.colors.get(role, s.get('fill')) if role else s.get('fill')
            if extra and s.get('fill') in extra:
                fill = extra[s['fill']]
            st = ''
            if s.get('stroke'):
                sr = s.get('srole')
                scol = self.colors.get(sr, s['stroke']) if sr else s['stroke']
                st = (f' stroke="{scol}" stroke-width="{s.get("sw", 1):.2f}" stroke-linecap="round" '
                      'stroke-linejoin="round"')
            out.append(f'<path d="{s["d"]}" fill="{fill or "none"}"{st}/>')
        return ''.join(out)

    def _head_frame(self, content):
        """Applique l'échelle de tête autour du pivot du cou (la tête reste attachée)."""
        if abs(self.head_scale - 1) < 1e-6:
            return content
        nx, ny = self.kit['neck_pivot']
        return f'<g transform="translate({nx},{ny}) scale({self.head_scale:.4f}) translate({-nx},{-ny})">{content}</g>'

    def blink_value(self, t):
        for b in self.blinks:
            if abs(t - b) < 0.09:
                return 1 - abs(t - b) / 0.09
            if b > t + 1:
                break
        return 0.0

    def head_svg(self, name, blink=0.0, talk=None):
        h = self.kit['heads'][name]
        fb, ref = h['face_bbox'], self.kit['face_ref']
        fc = ((fb[0] + fb[2]) / 2, (fb[1] + fb[3]) / 2)
        s = ref['w'] / (fb[2] - fb[0])
        eyes, mouth = set(h['eyes']), set(h['mouth'])
        mshapes = [h['shapes'][k] for k in mouth]
        parts = []
        for k, sh in enumerate(h['shapes']):
            one = self._paint([sh])
            if k in eyes and blink > 0:
                cx, cy = _center(sh['d'])
                one = f'<g transform="translate({cx:.2f},{cy:.2f}) scale(1,{max(.1, 1 - blink):.3f}) translate({-cx:.2f},{-cy:.2f})">{one}</g>'
            elif k in mouth and talk is not None and not h.get('mouth_line'):
                mx, my = _mouth_anchor(mshapes)
                one = (f'<g transform="translate({mx:.2f},{my:.2f}) scale({0.9 + 0.15 * talk:.3f},{0.35 + 1.25 * talk:.3f}) '
                       f'translate({-mx:.2f},{-my:.2f})">{one}</g>')
            parts.append(one)
        if h.get('mouth_line') and talk and mshapes:
            bbs = [_bbox_of(m['d']) for m in mshapes]
            x0, x1 = min(b[0] for b in bbs), max(b[2] for b in bbs)
            yb = max(b[3] for b in bbs)
            w = (x1 - x0) * 0.32
            col = self.colors.get('bouche', '#4A2520')
            parts.append(f'<ellipse cx="{(x0 + x1) / 2:.2f}" cy="{yb + w * 0.15 * talk:.2f}" rx="{w * (0.8 + 0.2 * talk):.2f}" '
                         f'ry="{max(0.2, w * 0.55 * talk):.2f}" fill="{col}"/>')
        sx = -s if h.get('mirror') else s
        return (f'<g transform="translate({ref["cx"]:.2f},{ref["cy"]:.2f}) scale({sx:.4f},{s:.4f}) '
                f'translate({-fc[0]:.2f},{-fc[1]:.2f})">{"".join(parts)}</g>')

    def arm_svg(self, pose, side, rot=0.0):
        """pose : nom de la planche ('R1'…'L4'), suffixe 'm' pour la version miroir. side : 'L' ou 'R' (écran)."""
        mirror = pose.endswith('m')
        a = self.kit['arms'][pose.rstrip('m')]
        sx0, sy0 = a['shoulder']
        px, py = self.kit['shoulders'][side]
        sc = self.kit['arm_scale']
        return (f'<g transform="translate({px},{py}) rotate({rot:.2f}) scale({-sc if mirror else sc},{sc}) '
                f'translate({-sx0:.2f},{-sy0:.2f})">{self._paint(a["shapes"])}</g>')

    def torso_svg(self):
        b, cid = self.kit['body'], f'torso{self.uid}'
        return (f'<clipPath id="{cid}"><path d="{self.kit["torso_clip"]}"/></clipPath>'
                + self._paint(b['neck'])
                + f'<g clip-path="url(#{cid})">{self._paint(b["under"])}{self._paint(b["jacket"])}</g>'
                + self._paint(b['over']))

    # ---------- personnage complet
    def draw(self, t, head='serein', left=('L3m', None), right=('L3', None), talk=None,
             tilt=0.0, lean=0.0, front=(), idle=True, blink=None, reactions=()):
        """Dessine le personnage dans les coordonnées du kit.
        left/right : (pose, rotation) ; rotation None = balancement de repos automatique.
        talk : ouverture de bouche 0..1 (None = bouche au repos). front : côtés de bras dessinés devant le torse.
        reactions : instants d'événements subis → à-coups de tête amortis (Bible, section 5)."""
        k = self.kit
        sway = math.sin(2 * math.pi * t / self.p_head + self.phase) if idle else 0
        breath = 1 + 0.01 * math.sin(2 * math.pi * t / self.p_breath + self.phase) if idle else 1
        tilt_total = tilt + 1.8 * sway + sum(3.5 * damped(t - r, 7, 7) for r in reactions)
        bl = self.blink_value(t) if blink is None else blink
        lp, lr = left
        rp, rr = right
        lr = 3 * sway if lr is None else lr
        rr = -3 * sway if rr is None else rr
        la, ra = self.arm_svg(lp, 'L', lr), self.arm_svg(rp, 'R', rr)
        behind = ('' if 'L' in front else la) + ('' if 'R' in front else ra)
        ahead = (la if 'L' in front else '') + (ra if 'R' in front else '')
        nx, ny = k['neck_pivot']
        hd = f'<g transform="rotate({tilt_total:.2f} {nx} {ny})">{self._head_frame(self.head_svg(head, bl, talk))}</g>'
        hb = ''
        if k['body'].get('hair_back'):                 # chevelure arrière : derrière bras et torse, tourne avec la tête
            hb = f'<g transform="rotate({tilt_total:.2f} {nx} {ny})">{self._head_frame(self._paint(k["body"]["hair_back"]))}</g>'
        oy = k['breath_origin_y']
        up = f'<g transform="translate(0,{oy}) scale(1,{breath:.4f}) translate(0,{-oy})">{hb}{behind}{self.torso_svg()}{hd}{ahead}</g>'
        fx, fy = k['feet']
        return f'<g transform="rotate({lean:.2f} {fx} {fy})">{self._paint(k["body"]["legs"])}{up}</g>'

    def place(self, svg, x, floor=FLOOR_Y, scale=None, dy=0.0, cut_y=None):
        """Place le personnage : pieds centrés en x sur la ligne de sol. Miroir appliqué ici.
        Derrière un bureau : scale=kit['scales']['behind_desk'] et floor = y du plateau + (447-235)*scale."""
        sc = scale or self.kit['scales']['full_body']
        fx, fy = self.kit['feet']
        sx = -sc if self.mirror else sc
        return f'<g transform="translate({x:.1f},{floor - fy * sc + dy:.1f}) scale({sx:.4f},{sc:.4f}) translate({-fx},0)">{svg}</g>'

    def hand_screen(self, pose, side, rot, x, floor=FLOOR_Y, scale=None, dy=0.0):
        """Position à l'écran (x, y) de la main d'une pose de bras, pour y poser un objet (téléphone, gobelet).
        Mêmes paramètres que draw() (pose, côté, rotation) et place() (x, sol, échelle). Ignore respiration et lean."""
        a = self.kit['arms'][pose.rstrip('m')]
        skin = [s for s in a['shapes'] if s.get('role') in ('peau', 'peau_claire')] or a['shapes']
        pts = [_center(s['d']) for s in skin]
        hx, hy = sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts)
        sx0, sy0 = a['shoulder']
        sc = self.kit['arm_scale'] * (-1 if pose.endswith('m') else 1)
        u, v = (hx - sx0) * sc, (hy - sy0) * self.kit['arm_scale']
        r = math.radians(rot)
        px, py = self.kit['shoulders'][side]
        kx, ky = px + u * math.cos(r) - v * math.sin(r), py + u * math.sin(r) + v * math.cos(r)
        S = scale or self.kit['scales']['full_body']
        fx, fy = self.kit['feet']
        X = (kx - fx) * (-S if self.mirror else S) + x
        Y = ky * S + floor - fy * S + dy
        return X, Y

    def hand_svg(self, name, tip_x, tip_y, rot, scale=6.2, sleeve=True):
        """Main seule en gros plan (vue plongeante), l'origine étant le bout de l'index."""
        h = self.kit['hands'][name]
        tx, ty = h['tip']; wx, wy = h['wrist']
        hand = f'<g transform="scale({scale}) translate({-tx},{-ty})">{self._paint(h["shapes"])}</g>'
        sl = ''
        if sleeve:
            ax, ay = (wx - tx) * scale, (wy - ty) * scale
            col = self.colors.get('veste', '#313e49')
            sl = f'<path d="M{ax-46:.1f} {ay-4:.1f} L{ax+46:.1f} {ay-4:.1f} L{ax+80:.1f} 900 L{ax-80:.1f} 900 Z" fill="{col}"/>'
        shadow = f'<g transform="translate(6,10)" opacity=".2">{hand}</g>'
        return f'<g transform="translate({tip_x:.1f},{tip_y:.1f}) rotate({rot:.2f})">{shadow}{sl}{hand}</g>'


# ---------- utilitaires géométriques (calculés une fois par chemin)
_cache = {}


def _bbox_of(d):
    if d not in _cache:
        from svgelements import Path as SPath
        _cache[d] = SPath(d).bbox()
    return _cache[d]


def _center(d):
    b = _bbox_of(d)
    return (b[0] + b[2]) / 2, (b[1] + b[3]) / 2


def _mouth_anchor(shapes):
    bbs = [_bbox_of(s['d']) for s in shapes]
    return sum((b[0] + b[2]) / 2 for b in bbs) / len(bbs), min(b[1] for b in bbs)


def swap_rotation(t, t0, rest, offset=25.0, dur=0.3, s=2.2):
    """Rotation d'un bras après substitution de pose : part de rest+offset et rebondit vers rest."""
    from .timing import back_out
    k = (t - t0) / dur
    if k >= 1:
        return rest
    return rest + offset * (1 - back_out(k, s))


def talk_curve(t, t0, t1, seed=0.0, rate=5.3):
    """Ouverture de bouche synthétique entre t0 et t1 (5,3 Hz modulé à 1,7 Hz) ; None en dehors."""
    if not (t0 <= t < t1):
        return None
    v = 0.5 + 0.5 * math.sin(2 * math.pi * rate * (t - t0) + seed) * (0.7 + 0.3 * math.sin(2 * math.pi * 1.7 * (t - t0)))
    return max(0.0, min(1.0, v))


def main_ecran(perso, x, sol, echelle, pose, cote, rotation=0.0):
    """Alias français de Character.hand_screen : (x, y) à l'écran de la main d'une pose de bras."""
    return perso.hand_screen(pose, cote, rotation, x, sol, echelle)
