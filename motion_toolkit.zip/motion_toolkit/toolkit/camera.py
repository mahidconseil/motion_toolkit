"""Caméra 2D : parallaxe, travellings, zooms, dérive (Bible, section 6). Calcul seulement, aucun décor.

    cam = Camera([(0, (0, 0, 1.0)), (4, (420, 0, 1.06))])     # (t, (x, y, zoom))
    svg = cam.layer(t, contenu_fond, 'fond') + cam.layer(t, contenu_jeu, 'jeu')
    svg = cam.frame(t, svg)                                     # applique le zoom
"""
import math

from .data import DESIGN, PARALLAXE
from .timing import keyframes, ease_in_out


class Camera:
    def __init__(self, keys=((0, (0, 0, 1.0)),), curve=ease_in_out, drift=4.0, drift_period=7.0, seed=0.0,
                 zoom_center=None):
        """keys : [(t, (x, y, zoom)), …]. drift : amplitude de la dérive permanente (unités)."""
        self.keys, self.curve = list(keys), curve
        self.drift, self.period, self.seed = drift, drift_period, seed
        self.center = zoom_center or (DESIGN[0] / 2, DESIGN[1] / 2)

    def state(self, t):
        x, y, z = keyframes(t, self.keys, self.curve) if len(self.keys) > 1 else self.keys[0][1]
        dx = self.drift * math.sin(2 * math.pi * t / self.period + self.seed)
        dy = self.drift * 0.5 * math.sin(2 * math.pi * t / (self.period * 1.37) + self.seed * 2)
        return x + dx, y + dy, z

    def layer(self, t, content, depth='jeu'):
        """Décale une couche selon sa vitesse : 'fond' 0,2 · 'aplats' 0,5 · 'jeu' 1,0 · 'premier_plan' 1,4 (ou un nombre)."""
        k = PARALLAXE[depth] if isinstance(depth, str) else depth
        x, y, _ = self.state(t)
        return f'<g transform="translate({-x * k:.2f},{-y * k:.2f})">{content}</g>'

    def frame(self, t, content):
        """Applique le zoom de la caméra autour du centre de zoom."""
        _, _, z = self.state(t)
        if abs(z - 1) < 1e-6:
            return content
        cx, cy = self.center
        return f'<g transform="translate({cx},{cy}) scale({z:.5f}) translate({-cx},{-cy})">{content}</g>'


def zoom_about(content, cx, cy, z):
    """Zoom autour d'un point (push-through, gros plan)."""
    return f'<g transform="translate({cx},{cy}) scale({z:.5f}) translate({-cx},{-cy})">{content}</g>'
