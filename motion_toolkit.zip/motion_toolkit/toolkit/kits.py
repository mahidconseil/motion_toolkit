"""Intégration d'un kit personnage vectoriel (Bible, sections 3 et 10).

Procédure : unzip_kit() → convert() → load_shapes() → inventory() (planche quadrillée, validée par l'utilisateur)
→ repérage des zones (corps, têtes, bras, mains) → colors_report() → calibration → save_kit().

Schéma du fichier de calibration (JSON), lu par rig.Character :
{
  "name", "source", "attribution",
  "body": {"neck": [forme], "under": [forme], "jacket": [forme], "over": [forme], "legs": [forme]},
  "torso_clip": "chemin SVG du masque du torse (retire les bras dessinés avec la veste)",
  "face_ref": {"cx", "cy", "w"},                  # visage de référence sur lequel les têtes sont recalées
  "neck_pivot": [x, y], "shoulders": {"L": [x, y], "R": [x, y]}, "breath_origin_y": y, "feet": [x, y],
  "arm_scale": nombre,
  "heads": {nom: {"shapes": [forme], "face_bbox": [x0, y0, x1, y1], "eyes": [index], "mouth": [index], "mirror": bool,
                  "mouth_line"?: bool, "profil"?: bool}},
  "arms": {nom: {"shapes": [forme], "shoulder": [x, y]}},
  "hands": {nom: {"shapes": [forme], "tip": [x, y], "wrist": [x, y]}},
  "scales": {"full_body": nombre, "behind_desk": nombre}
}
forme = {"d": chemin, "fill": couleur d'origine, "role": rôle de couleur ou null,
         "stroke"?: couleur de trait, "sw"?: épaisseur, "srole"?: rôle de couleur du trait}
Extensions facultatives : "head_scale": nombre (harmoniser deux kits), body["hair_back"]: [forme] (chevelure dessinée
derrière bras et torse, tourne avec la tête), heads[nom]["mouth_line"]: true (bouche en trait : la parole ajoute une
ouverture sombre), heads[nom]["profil"]: true (tête de profil, utilisable sur un corps de face).
Rôles de couleur usuels : veste, revers, chemise, col, col_ombre, cravate, pantalon, chaussettes,
peau, peau_claire, peau_ombre, peau_trait, cheveux.
"""
import json, os, shutil, subprocess, zipfile

import cairosvg
from svgelements import SVG, Shape, Path as SPath


def _ensure_gs():
    if shutil.which('gs'):
        return
    subprocess.run('apt-get update -q >/dev/null 2>&1; apt-get install -y -q ghostscript >/dev/null 2>&1',
                   shell=True)
    if not shutil.which('gs'):
        raise RuntimeError("Ghostscript introuvable : nécessaire pour lire un .eps")


def unzip_kit(zip_path, out_dir, choose=True):
    """Décompresse un zip de kit et renvoie le meilleur fichier vectoriel.
    choose=True : quand plusieurs sources existent (.ai et .eps), convertit chacune et garde celle qui donne
    le plus de formes (un .ai peut n'en donner que 60 contre 304 pour le .eps). choose=False : .ai prioritaire."""
    os.makedirs(out_dir, exist_ok=True)
    with zipfile.ZipFile(zip_path) as z:
        z.extractall(out_dir)
    files = sorted(os.path.join(r, f) for r, _, fs in os.walk(out_dir) for f in fs
                   if not f.startswith('._') and '__MACOSX' not in r)
    cands = [f for f in files if os.path.splitext(f)[1].lower() in ('.ai', '.eps', '.pdf', '.svg')]
    if not cands:
        raise FileNotFoundError("Aucun fichier vectoriel (.ai, .eps, .pdf, .svg) dans le zip")
    if not choose or len(cands) == 1:
        order = {'.ai': 0, '.eps': 1, '.pdf': 2, '.svg': 3}
        return sorted(cands, key=lambda f: order[os.path.splitext(f)[1].lower()])[0]
    return best_source(cands, out_dir)


def best_source(candidates, work_dir):
    """Convertit chaque source candidate et renvoie celle qui produit le plus de formes (affiche le décompte)."""
    best, n_best = None, -1
    for k, src in enumerate(candidates):
        try:
            svg = convert(src, os.path.join(work_dir, f'_cand{k}.svg'))
            n = len(load_shapes(svg))
        except Exception as e:                              # source illisible : ignorée
            print(f'  {os.path.basename(src)} : illisible ({e.__class__.__name__})')
            continue
        print(f'  {os.path.basename(src)} : {n} formes')
        if n > n_best:
            best, n_best = src, n
    if best is None:
        raise RuntimeError('Aucune source convertible')
    return best


def convert(src, out_svg):
    """Convertit .ai / .eps / .pdf en SVG (les .ai Illustrator sont lisibles comme des PDF)."""
    ext = os.path.splitext(src)[1].lower()
    if ext == '.svg':
        shutil.copy(src, out_svg)
        return out_svg
    pdf = src
    if ext == '.eps':
        _ensure_gs()
        pdf = os.path.splitext(out_svg)[0] + '.pdf'
        subprocess.run(['gs', '-q', '-dNOPAUSE', '-dBATCH', '-dSAFER', '-dEPSCrop', '-sDEVICE=pdfwrite',
                        f'-sOutputFile={pdf}', src], check=True)
    subprocess.run(['pdftocairo', '-svg', pdf, out_svg], check=True)
    return out_svg


def load_shapes(svg_path):
    """Liste des formes : i, d (chemin transformé), fill, bb (x0,y0,x1,y1), cx, cy."""
    s = SVG.parse(svg_path)
    out = []
    for e in s.elements():
        if not isinstance(e, Shape):
            continue
        bb = e.bbox()
        if bb is None:
            continue
        p = SPath(e)
        p.reify()
        fill = None if e.fill is None or e.fill.value is None else e.fill.hex
        stroke = None if e.stroke is None or e.stroke.value is None else e.stroke.hex
        out.append(dict(i=len(out), d=p.d(), fill=fill, stroke=stroke,
                        sw=float(getattr(e, "implicit_stroke_width", e.stroke_width) or 0) if stroke else 0.0,
                        bb=[float(v) for v in bb], cx=(bb[0] + bb[2]) / 2, cy=(bb[1] + bb[3]) / 2))
    return out


def region(shapes, x0, y0, x1, y1, by='center'):
    """Formes d'une zone de la planche : par centre (défaut) ou entièrement contenues ('inside')."""
    res = []
    for e in shapes:
        b = e['bb']
        if by == 'inside':
            ok = b[0] >= x0 and b[2] <= x1 and b[1] >= y0 and b[3] <= y1
        else:
            ok = x0 <= e['cx'] < x1 and y0 <= e['cy'] < y1
        if ok:
            res.append(e)
    return res


def bbox(shapes):
    return (min(e['bb'][0] for e in shapes), min(e['bb'][1] for e in shapes),
            max(e['bb'][2] for e in shapes), max(e['bb'][3] for e in shapes))


def shapes_svg(shapes, label_ids=False):
    out = []
    for e in shapes:
        st = ''
        if e.get('stroke'):
            st = f' stroke="{e["stroke"]}" stroke-width="{e["sw"]:.2f}"'
        out.append(f'<path d="{e["d"]}" fill="{e["fill"] or "none"}"{st}/>')
    if label_ids:
        for e in shapes:
            out.append(f'<text x="{e["cx"]:.1f}" y="{e["cy"]:.1f}" font-size="3" fill="#E00" '
                       f'font-family="DejaVu Sans">{e["i"]}</text>')
    return ''.join(out)


def render_shapes(shapes, out_png, scale=3, pad=4, bg='#E7E5E5', label_ids=False, grid=None):
    """Rend des formes en PNG. grid=25 superpose une grille cotée tous les 25 points (repérage des zones)."""
    x0, y0, x1, y1 = bbox(shapes)
    x0 -= pad; y0 -= pad; w = x1 - x0 + pad; h = y1 - y0 + pad
    g = ''
    if grid:
        gx = int(x0 // grid) * grid
        while gx < x0 + w:
            g += (f'<line x1="{gx}" y1="{y0}" x2="{gx}" y2="{y0+h}" stroke="#3A7BD5" stroke-width=".25"/>'
                  f'<text x="{gx+1}" y="{y0+5}" font-size="4" fill="#3A7BD5" font-family="DejaVu Sans">{gx}</text>')
            gx += grid
        gy = int(y0 // grid) * grid
        while gy < y0 + h:
            g += (f'<line x1="{x0}" y1="{gy}" x2="{x0+w}" y2="{gy}" stroke="#3A7BD5" stroke-width=".25"/>'
                  f'<text x="{x0+1}" y="{gy-1}" font-size="4" fill="#3A7BD5" font-family="DejaVu Sans">{gy}</text>')
            gy += grid
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{x0} {y0} {w} {h}" '
           f'width="{w*scale:.0f}" height="{h*scale:.0f}"><rect x="{x0}" y="{y0}" width="{w}" height="{h}" fill="{bg}"/>'
           f'{shapes_svg(shapes, label_ids)}{g}</svg>')
    cairosvg.svg2png(bytestring=svg.encode(), write_to=out_png)
    return out_png


def inventory(shapes, out_png, skip_first=True, scale=2, grid=25):
    """Planche d'inventaire : toute la planche du kit avec une grille cotée, pour repérer les zones."""
    sh = shapes[1:] if skip_first else shapes
    return render_shapes(sh, out_png, scale=scale, grid=grid)


def sleeve_shoulder(group, sleeve_fill, skin_fills, sample=500, radius=7.0, methode='auto'):
    """Point d'épaule d'une pose de bras.
    'haut' : centre de l'extrémité haute de la manche (fiable pour les bras baissés ou pliés vers le bas).
    'loin' : extrémité de la manche la plus éloignée de la main (fiable pour les bras levés).
    'auto' (défaut) : 'haut' si la main est sous le centre de la manche, sinon 'loin'.
    Toujours vérifier sur la planche de poses."""
    sleeves = [e for e in group if e['fill'] == sleeve_fill]
    sleeve = max(sleeves, key=lambda e: (e['bb'][2] - e['bb'][0]) * (e['bb'][3] - e['bb'][1]))
    skin = [e for e in group if e['fill'] in skin_fills]
    hx = sum(e['cx'] for e in skin) / len(skin)
    hy = sum(e['cy'] for e in skin) / len(skin)
    p = SPath(sleeve['d'])
    pts = [p.point(k / sample) for k in range(sample)]
    if methode == 'auto':
        methode = 'haut' if hy > sleeve['cy'] else 'loin'
    if methode == 'haut':
        top = min(pts, key=lambda q: q.y)
        near = [q for q in pts if q.y < top.y + radius]
        return [float(sum(q.x for q in near) / len(near)), float(top.y + radius * 0.55)]
    far = max(pts, key=lambda q: (q.x - hx) ** 2 + (q.y - hy) ** 2)
    near = [q for q in pts if (q.x - far.x) ** 2 + (q.y - far.y) ** 2 < 12 ** 2]
    return [float(sum(q.x for q in near) / len(near)), float(sum(q.y for q in near) / len(near))]


def pack(shapes, roles, stroke_roles=None):
    """Formes réduites à ce que le rig utilise : rôle de remplissage (None = couleur d'origine) et, pour les formes
    à trait (nez, bouche, oreilles de nombreux kits), trait, épaisseur et rôle de trait."""
    out = []
    sroles = stroke_roles or roles
    for e in shapes:
        f = dict(d=e['d'], fill=e['fill'], role=roles.get(e['fill']))
        if e.get('stroke'):
            f.update(stroke=e['stroke'], sw=round(float(e.get('sw') or 1.0), 3), srole=sroles.get(e['stroke']))
        out.append(f)
    return out


def save_kit(kit, path):
    with open(path, 'w') as f:
        json.dump(kit, f, separators=(',', ':'))
    return path


def colors_report(shapes):
    """Couleurs du kit triées par surface approximative : base de la table de rôles et de la recoloration."""
    acc = {}
    for e in shapes:
        if e['fill']:
            b = e['bb']
            acc[e['fill']] = acc.get(e['fill'], 0) + (b[2] - b[0]) * (b[3] - b[1])
    return sorted(acc.items(), key=lambda kv: -kv[1])


def nearest_palette(hexc):
    """Couleur de la palette Google la plus proche (teinte, nuance, hex) : pour ramener un kit à la palette."""
    from .data import PALETTE
    def rgb(h):
        h = h.lstrip('#'); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    r0 = rgb(hexc)
    best = None
    for teinte, ramp in PALETTE.items():
        for nuance, hx in ramp.items():
            d = sum((a - b) ** 2 for a, b in zip(r0, rgb(hx)))
            if best is None or d < best[0]:
                best = (d, teinte, nuance, hx)
    return best[1:]


def swatches(colors, out_png, size=60):
    """Planche des couleurs d'un kit avec leur équivalent palette (contrôle de la recoloration)."""
    import cairosvg
    rows = ''
    for k, (hx, _) in enumerate(colors):
        t, n, ph = nearest_palette(hx)
        y = 10 + k * (size + 10)
        rows += (f'<rect x="10" y="{y}" width="{size}" height="{size}" fill="{hx}"/>'
                 f'<rect x="{size + 20}" y="{y}" width="{size}" height="{size}" fill="{ph}"/>'
                 f'<text x="{2 * size + 35}" y="{y + size / 2 + 5}" font-size="16" font-family="DejaVu Sans">{hx} → {t} {n} ({ph})</text>')
    h = 20 + len(colors) * (size + 10)
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="560" height="{h}"><rect width="560" height="{h}" fill="#fff"/>{rows}</svg>'
    cairosvg.svg2png(bytestring=svg.encode(), write_to=out_png)
    return out_png
