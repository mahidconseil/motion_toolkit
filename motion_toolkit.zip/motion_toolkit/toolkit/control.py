"""Storyboard, planches de contrôle et vérifications automatiques (Bible, section 9)."""
import os, re, subprocess

from PIL import Image, ImageDraw, ImageFont

_FONT = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'


def _font(size):
    try:
        return ImageFont.truetype(_FONT, size)
    except OSError:
        return ImageFont.load_default()


def _tc_filter(w, h):
    return (f"scale={w}:{h},drawtext=text='%{{pts\\:hms}}  i%{{eif\\:t*25\\:d}}':x=6:y=6:fontsize={max(12, h // 12)}:"
            "fontcolor=yellow:box=1:boxcolor=black@0.6")


def contact_sheet(video, out_png, every=10, cols=5, width=320):
    """Une image toutes les `every` images, minutage et numéro d'image incrustés."""
    h = int(width * 9 / 16)
    n = int(subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-count_packets', '-show_entries',
                            'stream=nb_read_packets', '-of', 'csv=p=0', video], capture_output=True, text=True).stdout.strip() or 0)
    rows = max(1, -(-(n // every + 1) // cols))
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', video, '-vf',
                    f"select='not(mod(n\\,{every}))',{_tc_filter(width, h)},tile={cols}x{rows}",
                    '-frames:v', '1', '-update', '1', out_png], check=True)
    return out_png


def strip(video, t, out_png, n=10, width=256):
    """n images consécutives à partir de t (s), sur une ligne, minutage incrusté."""
    h = int(width * 9 / 16)
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', f'{t:.3f}', '-copyts', '-i', video, '-vf',
                    f'{_tc_filter(width, h)},tile={n}x1', '-frames:v', '1', '-update', '1', out_png], check=True)
    return out_png


def strips(video, times, out_png, n=10, width=200):
    """Plusieurs bandes empilées (une par instant : transitions, points de synchro)."""
    tmp = []
    for k, t in enumerate(times):
        p = f'{out_png}.{k}.png'
        strip(video, t, p, n, width)
        tmp.append(Image.open(p))
    W = max(i.width for i in tmp)
    out = Image.new('RGB', (W, sum(i.height for i in tmp)), 'black')
    y = 0
    for i in tmp:
        out.paste(i, (0, y)); y += i.height
    out.save(out_png)
    for k in range(len(times)):
        os.remove(f'{out_png}.{k}.png')
    return out_png


def zoom(frame_png, box, out_png, factor=3):
    """Agrandit une zone (x0, y0, x1, y1) d'une image."""
    im = Image.open(frame_png).crop(box)
    im = im.resize((im.width * factor, im.height * factor), Image.LANCZOS)
    im.save(out_png)
    return out_png


def board(images, captions, out_png, cols=3, width=560):
    """Planche de storyboard : images légendées (n° et durée, action, mouvements, transition, synchro)."""
    h = int(width * 9 / 16)
    cap_h = 120
    rows = -(-len(images) // cols)
    out = Image.new('RGB', (cols * (width + 20) + 20, rows * (h + cap_h + 20) + 20), '#F7F6FA')
    d = ImageDraw.Draw(out)
    f = _font(15)
    for k, (img, cap) in enumerate(zip(images, captions)):
        r, c = divmod(k, cols)
        x, y = 20 + c * (width + 20), 20 + r * (h + cap_h + 20)
        im = Image.open(img).convert('RGB').resize((width, h))
        out.paste(im, (x, y))
        lines, cur = [], ''
        for word in str(cap).split():
            if d.textlength(cur + ' ' + word, font=f) > width:
                lines.append(cur); cur = word
            else:
                cur = (cur + ' ' + word).strip()
        lines.append(cur)
        for i, ln in enumerate(lines[:6]):
            d.text((x, y + h + 6 + i * 19), ln, fill='#332B2B', font=f)
    out.save(out_png)
    return out_png


def detect_cuts(video, threshold=0.2):
    r = subprocess.run(['ffmpeg', '-i', video, '-map', '0:v:0', '-vf', f"select='gt(scene,{threshold})',showinfo",
                        '-f', 'null', '-'], capture_output=True, text=True)
    return [float(v) for v in re.findall(r'pts_time:([0-9.]+)', r.stderr)]


def sync_report(video, grid, threshold=0.2, fps=25):
    """Écart (en images) entre chaque coupe détectée et le temps musical le plus proche."""
    rep = []
    for c in detect_cuts(video, threshold):
        b = min(grid['beats'], key=lambda v: abs(v - c)) if grid['beats'] else c
        rep.append(dict(cut=round(c, 3), beat=b, offset_frames=round((c - b) * fps)))
    return rep


def freezes(video, min_dur=0.6, noise=0.0008):
    """Passages figés (aucun mouvement pendant ≥ min_dur s) : un personnage doit toujours respirer."""
    r = subprocess.run(['ffmpeg', '-i', video, '-vf', f'freezedetect=n={noise}:d={min_dur}', '-map', '0:v:0',
                        '-f', 'null', '-'], capture_output=True, text=True)
    st = [float(v) for v in re.findall(r'freeze_start: ([0-9.]+)', r.stderr)]
    en = [float(v) for v in re.findall(r'freeze_end: ([0-9.]+)', r.stderr)]
    return [(a, b) for a, b in zip(st, en + [None] * (len(st) - len(en)))]


def blanks(video, min_dur=0.2):
    """Passages noirs ou blancs (images vides) hors fondu final."""
    out = []
    for vf, kind in (('blackdetect', 'noir'), ('negate,blackdetect', 'blanc')):
        r = subprocess.run(['ffmpeg', '-i', video, '-vf', f'{vf}=d={min_dur}:pix_th=0.05', '-map', '0:v:0',
                            '-f', 'null', '-'], capture_output=True, text=True)
        for a, b in re.findall(r'black_start:([0-9.]+) black_end:([0-9.]+)', r.stderr):
            out.append((kind, float(a), float(b)))
    return out


def report(video, target_duration=None, grid=None, fps=25):
    """Vérifications automatiques de la liste de contrôle : durée, synchro, gels, images vides, volume.
    Renvoie (dict, liste de problèmes). Le reste de la liste se vérifie à l'œil sur les planches."""
    from .render import duration_of
    from .audio import loudness
    d = duration_of(video)
    res, issues = dict(duration=round(d, 3)), []
    if target_duration and abs(d - target_duration) > 1 / fps + 1e-6:
        issues.append(f'durée {d:.3f} s au lieu de {target_duration:.3f} s')
    if grid:
        sr = sync_report(video, grid, fps=fps)
        res['sync'] = sr
        issues += [f"coupe à {s['cut']} s décalée de {s['offset_frames']} image(s)" for s in sr if abs(s['offset_frames']) > 1]
    fz = freezes(video)
    res['freezes'] = fz
    issues += [f'image figée de {a:.2f} à {b if b is None else round(b, 2)} s' for a, b in fz if b is None or b < d - 0.6]
    bl = blanks(video)
    res['blanks'] = bl
    issues += [f'passage {k} de {a:.2f} à {b:.2f} s' for k, a, b in bl if a < d - 1.0]
    lu = loudness(video)
    res['lufs'] = lu
    if lu is not None and d >= 5 and abs(lu + 14) > 1.0:   # sous 5 s, la mesure n'est pas fiable
        issues.append(f'volume {lu} LUFS au lieu de −14')
    return res, issues
