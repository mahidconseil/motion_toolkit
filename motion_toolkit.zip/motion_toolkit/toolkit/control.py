"""Storyboard, planches de contrôle et vérifications automatiques (Bible, section 9)."""
import os, re, subprocess

from PIL import Image, ImageDraw, ImageFont

_FONT = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'


def _font(size):
    try:
        return ImageFont.truetype(_FONT, size)
    except OSError:
        return ImageFont.load_default()


def _tc_filter(w, h):
    return (f"scale={w}:{h},drawtext=text='%{{pts\\:hms}}  i%{{eif\\:t*25\\:d}}':x=4:y=4:fontsize={max(9, min(h // 12, w // 13))}:"
            "fontcolor=yellow:box=1:boxcolor=black@0.6")


def video_size(video):
    r = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height',
                        '-of', 'csv=p=0', video], capture_output=True, text=True).stdout.strip().split(',')
    return int(r[0]), int(r[1])


def _thumb(video, width, ratio=None):
    """Taille de vignette au format du film (9:16 vertical détecté automatiquement)."""
    if ratio is None:
        w, h = video_size(video)
        ratio = h / w
    return width, int(round(width * ratio / 2) * 2)


def contact_sheet(video, out_png, every=10, cols=None, width=None, ratio=None):
    """Une image toutes les `every` images, minutage et n° d'image incrustés, au format du film
    (vignettes verticales pour un Reel). ratio = hauteur/largeur pour forcer un format."""
    vw, vh = video_size(video)
    vertical = (ratio or vh / vw) > 1
    cols = cols or (8 if vertical else 5)
    width = width or (180 if vertical else 320)
    tw, th = _thumb(video, width, ratio)
    n = int(subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-count_packets', '-show_entries',
                            'stream=nb_read_packets', '-of', 'csv=p=0', video], capture_output=True, text=True).stdout.strip() or 0)
    rows = max(1, -(-(n // every + 1) // cols))
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', video, '-vf',
                    f"select='not(mod(n\\,{every}))',{_tc_filter(tw, th)},tile={cols}x{rows}",
                    '-frames:v', '1', '-update', '1', out_png], check=True)
    return out_png


def strip(video, t, out_png, n=10, width=None, ratio=None):
    """n images consécutives à partir de t (s), sur une ligne, minutage incrusté, au format du film."""
    vw, vh = video_size(video)
    width = width or (120 if vh > vw else 256)
    width, h = _thumb(video, width, ratio)
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', f'{t:.3f}', '-copyts', '-i', video, '-vf',
                    f'{_tc_filter(width, h)},tile={n}x1', '-frames:v', '1', '-update', '1', out_png], check=True)
    return out_png


def strips(video, times, out_png, n=10, width=None):
    """Plusieurs bandes empilées (une par instant : transitions, points de synchro)."""
    tmp = []
    for k, t in enumerate(times):
        p = f'{out_png}.{k}.png'
        strip(video, t, p, n, width)
        tmp.append(Image.open(p))
    W = max(i.width for i in tmp)
    out = Image.new('RGB', (W, sum(i.height for i in tmp)), 'black')
    y = 0
    for i in tmp:
        out.paste(i, (0, y)); y += i.height
    out.save(out_png)
    for k in range(len(times)):
        os.remove(f'{out_png}.{k}.png')
    return out_png


def zoom(frame_png, box, out_png, factor=3):
    """Agrandit une zone (x0, y0, x1, y1) d'une image (facteur décimal accepté)."""
    im = Image.open(frame_png).crop(tuple(int(round(v)) for v in box))
    im = im.resize((max(1, int(round(im.width * factor))), max(1, int(round(im.height * factor)))), Image.LANCZOS)
    im.save(out_png)
    return out_png


def board(images, captions, out_png, cols=None, width=None, ratio=None):
    """Planche de storyboard : images légendées (n° et durée, action, valeur et angle, caméra, transition, synchro).
    Format détecté sur la première image (Reel vertical : 5 colonnes plus étroites)."""
    first = Image.open(images[0])
    ratio = ratio or first.height / first.width
    vertical = ratio > 1
    cols = cols or (5 if vertical else 3)
    width = width or (300 if vertical else 560)
    h = int(width * ratio)
    cap_h = 140
    rows = -(-len(images) // cols)
    out = Image.new('RGB', (cols * (width + 20) + 20, rows * (h + cap_h + 20) + 20), '#F7F6FA')
    d = ImageDraw.Draw(out)
    f = _font(14 if vertical else 15)
    for k, (img, cap) in enumerate(zip(images, captions)):
        r, c = divmod(k, cols)
        x, y = 20 + c * (width + 20), 20 + r * (h + cap_h + 20)
        out.paste(Image.open(img).convert('RGB').resize((width, h)), (x, y))
        lines, cur = [], ''
        for word in str(cap).split():
            if d.textlength(cur + ' ' + word, font=f) > width:
                lines.append(cur); cur = word
            else:
                cur = (cur + ' ' + word).strip()
        lines.append(cur)
        for i, ln in enumerate(lines[:7]):
            d.text((x, y + h + 6 + i * 18), ln, fill='#332B2B', font=f)
    out.save(out_png)
    return out_png


def detect_cuts(video, threshold=0.2):
    r = subprocess.run(['ffmpeg', '-i', video, '-map', '0:v:0', '-vf', f"select='gt(scene,{threshold})',showinfo",
                        '-f', 'null', '-'], capture_output=True, text=True)
    return [float(v) for v in re.findall(r'pts_time:([0-9.]+)', r.stderr)]


def sync_report(video, grid, threshold=0.2, fps=25):
    """Écart (en images) entre chaque coupe détectée et le temps musical le plus proche."""
    rep = []
    for c in detect_cuts(video, threshold):
        b = min(grid['beats'], key=lambda v: abs(v - c)) if grid['beats'] else c
        rep.append(dict(cut=round(c, 3), beat=b, offset_frames=round((c - b) * fps)))
    return rep


def _hors(intervalles, ignorer, marge=0.05):
    """Retire les intervalles qui tombent dans les passages déclarés voulus [(t0, t1), …]."""
    out = []
    for it in intervalles:
        a, b = it[-2], it[-1]
        bb = b if b is not None else a
        if any(a >= i0 - marge and bb <= i1 + marge for i0, i1 in (ignorer or [])):
            continue
        out.append(it)
    return out


def freezes(video, min_dur=0.6, noise=0.0008, ignorer=None):
    """Passages figés (aucun mouvement pendant ≥ min_dur s). ignorer = passages voulus [(t0, t1)]
    (image fixe d'un teaser, blanc de silence, carton). noise : tolérance (0,003 tolère une bouche seule)."""
    r = subprocess.run(['ffmpeg', '-i', video, '-vf', f'freezedetect=n={noise}:d={min_dur}', '-map', '0:v:0',
                        '-f', 'null', '-'], capture_output=True, text=True)
    st = [float(v) for v in re.findall(r'freeze_start: ([0-9.]+)', r.stderr)]
    en = [float(v) for v in re.findall(r'freeze_end: ([0-9.]+)', r.stderr)]
    return _hors([(a, b) for a, b in zip(st, en + [None] * (len(st) - len(en)))], ignorer)


def blanks(video, min_dur=0.2, ignorer=None):
    """Passages noirs ou blancs (images vides). ignorer = passages voulus [(t0, t1)]."""
    out = []
    for vf, kind in (('blackdetect', 'noir'), ('negate,blackdetect', 'blanc')):
        r = subprocess.run(['ffmpeg', '-i', video, '-vf', f'{vf}=d={min_dur}:pix_th=0.05', '-map', '0:v:0',
                            '-f', 'null', '-'], capture_output=True, text=True)
        for a, b in re.findall(r'black_start:([0-9.]+) black_end:([0-9.]+)', r.stderr):
            out.append((kind, float(a), float(b)))
    return _hors(out, ignorer)


def deplacement_global(video, t0=0.0, t1=None, width=320, flash=0.25, fps=25):
    """Déplacement global d'une image à la suivante, par corrélation de phase (garantir une image fixe).
    Ignore les images de flash (variation moyenne de luminance > `flash`). Renvoie (liste (t, dx, dy), max en px
    à l'échelle de la vidéo d'origine)."""
    import numpy as np
    vw, vh = video_size(video)
    w = width
    h = int(round(width * vh / vw / 2) * 2)
    args = ['ffmpeg', '-v', 'error', '-ss', f'{t0:.3f}', '-i', video]
    if t1 is not None:
        args += ['-t', f'{t1 - t0:.3f}']
    raw = subprocess.run(args + ['-vf', f'scale={w}:{h},format=gray', '-f', 'rawvideo', '-'],
                         capture_output=True, check=True).stdout
    fr = np.frombuffer(raw, np.uint8).reshape(-1, h, w).astype(np.float32) / 255
    win = np.outer(np.hanning(h), np.hanning(w))
    out, prev = [], None
    for k, f in enumerate(fr):
        if prev is not None and abs(f.mean() - prev.mean()) < flash:
            A, B = np.fft.fft2((prev - prev.mean()) * win), np.fft.fft2((f - f.mean()) * win)
            R = A * np.conj(B)
            R /= np.abs(R) + 1e-9
            c = np.abs(np.fft.ifft2(R))
            y, x = np.unravel_index(np.argmax(c), c.shape)
            dy = y - h if y > h // 2 else y
            dx = x - w if x > w // 2 else x
            out.append((round(t0 + k / fps, 3), float(dx * vw / w), float(dy * vw / w)))
        prev = f
    mx = max((abs(dx) + abs(dy) for _, dx, dy in out), default=0.0)
    return out, mx


def sync_timeline(plans, grid, fps=25, cle='beats'):
    """Synchro vérifiée sur la ligne de temps du projet (les transitions glissées échappent à la détection) :
    écart en images entre chaque début de plan et le temps musical le plus proche."""
    pts = grid.get(cle) or []
    rep = []
    for p in plans[1:]:
        t = p['debut']
        b = min(pts, key=lambda v: abs(v - t)) if pts else t
        rep.append(dict(plan=p.get('id'), debut=t, temps=b, offset_frames=round((t - b) * fps)))
    return rep


def report(video, target_duration=None, grid=None, fps=25, ignorer=None, plans=None, fixes=None):
    """Vérifications automatiques : durée, synchro (sur la ligne de temps si `plans` est fourni, sinon par détection
    des coupes), gels et images vides hors passages voulus (`ignorer`), image fixe garantie sur les passages
    `fixes` [(t0, t1)] (teaser), volume. Renvoie (dict, liste de problèmes)."""
    from .render import duration_of
    from .audio import loudness
    d = duration_of(video)
    res, issues = dict(duration=round(d, 3)), []
    if target_duration and abs(d - target_duration) > 1 / fps + 1e-6:
        issues.append(f'durée {d:.3f} s au lieu de {target_duration:.3f} s')
    if grid:
        if plans:
            sr = sync_timeline(plans, grid, fps)
            issues += [f"plan {s['plan']} à {s['debut']} s décalé de {s['offset_frames']} image(s)" for s in sr
                       if abs(s['offset_frames']) > 1]
        else:
            sr = sync_report(video, grid, fps=fps)
            issues += [f"coupe à {s['cut']} s décalée de {s['offset_frames']} image(s)" for s in sr
                       if abs(s['offset_frames']) > 1]
        res['sync'] = sr
    fz = freezes(video, ignorer=ignorer)
    res['freezes'] = fz
    issues += [f'image figée de {a:.2f} à {b if b is None else round(b, 2)} s' for a, b in fz if b is None or b < d - 0.6]
    bl = blanks(video, ignorer=ignorer)
    res['blanks'] = bl
    issues += [f'passage {k} de {a:.2f} à {b:.2f} s' for k, a, b in bl if a < d - 1.0]
    for t0, t1 in (fixes or []):
        _, mx = deplacement_global(video, t0, t1)
        res.setdefault('fixes', []).append((t0, t1, round(mx, 1)))
        if mx > 1.0:
            issues.append(f'image censée fixe de {t0} à {t1} s : déplacement global de {mx:.1f} px')
    lu = loudness(video)
    res['lufs'] = lu
    if lu is not None and d >= 5 and abs(lu + 14) > 1.0:   # sous 5 s, la mesure n'est pas fiable
        issues.append(f'volume {lu} LUFS au lieu de −14')
    return res, issues
