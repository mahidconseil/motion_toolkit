"""Analyse d'une vidéo de référence (Bible, étape 1)."""
import json, os, subprocess

import numpy as np
from PIL import Image

from . import control


def analyze_reference(path, out_dir='projet/reference', cut_threshold=0.2):
    """Métadonnées, coupes, planches contact (2 i/s), bandes aux coupes, palette, audio.
    Renvoie un dict ; les images sont écrites dans out_dir, que Claude regarde ensuite une par une."""
    os.makedirs(out_dir, exist_ok=True)
    meta = json.loads(subprocess.run(['ffprobe', '-v', 'error', '-show_format', '-show_streams', '-of', 'json', path],
                                     capture_output=True, text=True).stdout)
    v = next(s for s in meta['streams'] if s['codec_type'] == 'video')
    dur = float(meta['format']['duration'])
    info = dict(width=v['width'], height=v['height'], fps=v['r_frame_rate'], duration=round(dur, 2),
                audio=any(s['codec_type'] == 'audio' for s in meta['streams']))
    # planches contact à 2 i/s, 20 vignettes par planche
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', path, '-map', '0:v:0', '-vf',
                    "fps=2,scale=384:-2,drawtext=text='%{pts\\:hms}':x=5:y=5:fontsize=18:fontcolor=yellow:box=1:boxcolor=black@0.6,tile=5x4",
                    os.path.join(out_dir, 'planche_%02d.png')], check=True)
    cuts = control.detect_cuts(path, cut_threshold)
    merged = []
    for c in cuts:
        if not merged or c - merged[-1] > 0.3:
            merged.append(c)
    if merged:
        control.strips(path, [max(0, c - 0.2) for c in merged[:12]], os.path.join(out_dir, 'coupes.png'), n=10, width=192)
    # palette dominante sur 8 images réparties
    pix = []
    for k in range(8):
        t = dur * (k + .5) / 8
        f = os.path.join(out_dir, f'_p{k}.png')
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', f'{t:.2f}', '-i', path, '-frames:v', '1',
                        '-vf', 'scale=480:-2', '-update', '1', f], check=True)
        pix.append(np.array(Image.open(f).convert('RGB')).reshape(-1, 3))
        os.remove(f)
    px = np.concatenate(pix)
    q = Image.fromarray(px.reshape(1, -1, 3).astype('uint8')).quantize(12, method=Image.Quantize.MEDIANCUT)
    pal = q.getpalette()[:36]
    palette = [('#%02X%02X%02X' % tuple(pal[i * 3:i * 3 + 3]), round(100 * c / len(px), 1))
               for c, i in sorted(q.getcolors(), reverse=True)]
    audio = None
    if info['audio']:
        wav = os.path.join(out_dir, '_ref.wav')
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', path, '-vn', '-ac', '1', '-ar', '22050', wav], check=True)
        from .audio import analyze
        g = analyze(wav, out_json=os.path.join(out_dir, 'grille_ref.json'), sheet_png=os.path.join(out_dir, 'audio.png'))
        audio = dict(tempo=g['tempo'], strong_onsets=g['strong_onsets'], sections=g['sections'])
        os.remove(wav)
    res = dict(info=info, cuts=[round(c, 2) for c in merged], palette=palette, audio=audio,
               images=sorted(os.listdir(out_dir)))
    with open(os.path.join(out_dir, 'analyse.json'), 'w') as f:
        json.dump(res, f, indent=1)
    return res
