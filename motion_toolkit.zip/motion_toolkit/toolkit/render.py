"""Rendu image par image (Bible, sections 1 et 10).

Une scène est une fonction frame(t) qui renvoie le contenu SVG d'une image dans le repère 1280×720
(sans balise <svg>). Les définitions (dégradés) peuvent être incluses dans le contenu.
    still(frame, 2.4, 'plan1.png')                                  # storyboard (1280×720)
    frames(frame, duree, 'images', size=SORTIES['apercu'])          # animatique
    video('images', 'animatique.mp4')
    puis audio.mix(...) pour la bande-son.
"""
import multiprocessing as mp
import os, shutil, subprocess, time

import cairosvg

from .data import FPS, FORMATS, SORTIES  # noqa: F401
from .svg import wrap


def design_of(fmt):
    """Repère de travail d'un format : '16:9' → 1280×720, '9:16' / 'reel' → 720×1280, '1:1' → 1080×1080."""
    if isinstance(fmt, (tuple, list)):
        return tuple(fmt)
    return FORMATS['9:16' if fmt == 'reel' else fmt]


def output_of(fmt, quality='final'):
    """Taille de sortie : final (1920×1080 / 1080×1920 / 1080×1080) ou apercu (taille du repère)."""
    d = design_of(fmt)
    if quality == 'apercu':
        return d
    if quality == 'vignette':
        return (d[0] // 2, d[1] // 2)
    return SORTIES['reel'] if d[1] > d[0] else (SORTIES['final'] if d[0] > d[1] else (1080, 1080))


def still(frame_fn, t, out_png, size=None, bg='#FFFFFF', format='16:9'):
    """Image fixe. format : '16:9', '9:16' (ou 'reel'), '1:1' ; size par défaut = taille du repère."""
    d = design_of(format)
    cairosvg.svg2png(bytestring=wrap(frame_fn(t), size or d, design=d, bg=bg).encode(), write_to=out_png)
    return out_png


_job = {}


def _one(k):
    t = k / _job['fps']
    cairosvg.svg2png(bytestring=wrap(_job['fn'](t), _job['size'], design=_job['design'], bg=_job['bg']).encode(),
                     write_to=os.path.join(_job['dir'], f'f{k:05d}.png'))
    return k


def frames(frame_fn, duration, out_dir, fps=FPS, size=None, workers=None, bg='#FFFFFF', verbose=True, format='16:9'):
    """Rend toutes les images en parallèle. Renvoie le nombre d'images.
    format : '16:9', '9:16' (ou 'reel'), '1:1' ; size par défaut = sortie finale du format."""
    if os.path.exists(out_dir):
        shutil.rmtree(out_dir)
    os.makedirs(out_dir)
    n = int(round(duration * fps))
    _job.update(fn=frame_fn, fps=fps, size=size or output_of(format), design=design_of(format), dir=out_dir, bg=bg)
    workers = workers or max(1, min(8, mp.cpu_count()))
    t0 = time.time()
    with mp.get_context('fork').Pool(workers) as pool:
        for _ in pool.imap_unordered(_one, range(n), chunksize=4):
            pass
    if verbose:
        print(f'{n} images en {time.time() - t0:.0f} s')
    return n


def video(frames_dir, out_mp4, fps=FPS, crf=18):
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-framerate', str(fps), '-i', os.path.join(frames_dir, 'f%05d.png'),
                    '-c:v', 'libx264', '-preset', 'medium', '-crf', str(crf), '-pix_fmt', 'yuv420p', out_mp4], check=True)
    return out_mp4


def duration_of(path):
    r = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', path],
                       capture_output=True, text=True)
    return float(r.stdout.strip())


def estimate(duration, size=(1920, 1080), workers=None):
    """Estimation du temps de calcul (s), à annoncer avant de demander l'autorisation.
    Étalonnée en production (2 processeurs) : 72 s de film en 720×1280 → 107 s ; 79,4 s en 1080×1920 → 165 s.
    Prévoir +50 % pour des scènes très chargées (décor enrichi, nombreux personnages)."""
    workers = workers or max(1, min(8, mp.cpu_count()))
    mpix = size[0] * size[1] / 1e6
    per_s_2cpu = 0.55 + 0.83 * mpix          # ≈1,3 s par seconde de film en 0,9 Mpx ; ≈2,1 s en 2,1 Mpx
    return duration * per_s_2cpu * 2 / workers
