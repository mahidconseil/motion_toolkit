"""Rendu image par image (Bible, sections 1 et 10).

Une scène est une fonction frame(t) qui renvoie le contenu SVG d'une image dans le repère 1280×720
(sans balise <svg>). Les définitions (dégradés) peuvent être incluses dans le contenu.
    still(frame, 2.4, 'plan1.png')                                  # storyboard (1280×720)
    frames(frame, duree, 'images', size=SORTIES['apercu'])          # animatique
    video('images', 'animatique.mp4')
    puis audio.mix(...) pour la bande-son.
"""
import multiprocessing as mp
import os, shutil, subprocess, time

import cairosvg

from .data import FPS, SORTIES  # noqa: F401
from .svg import wrap


def still(frame_fn, t, out_png, size=(1280, 720), bg='#FFFFFF'):
    cairosvg.svg2png(bytestring=wrap(frame_fn(t), size, bg=bg).encode(), write_to=out_png)
    return out_png


_job = {}


def _one(k):
    t = k / _job['fps']
    cairosvg.svg2png(bytestring=wrap(_job['fn'](t), _job['size'], bg=_job['bg']).encode(),
                     write_to=os.path.join(_job['dir'], f'f{k:05d}.png'))
    return k


def frames(frame_fn, duration, out_dir, fps=FPS, size=(1920, 1080), workers=None, bg='#FFFFFF', verbose=True):
    """Rend toutes les images en parallèle. Renvoie le nombre d'images.
    Ordre de grandeur sur 1 processeur : ~3 s de calcul par seconde de film en 1280×720, ~10 s en 1920×1080."""
    if os.path.exists(out_dir):
        shutil.rmtree(out_dir)
    os.makedirs(out_dir)
    n = int(round(duration * fps))
    _job.update(fn=frame_fn, fps=fps, size=size, dir=out_dir, bg=bg)
    workers = workers or max(1, min(8, mp.cpu_count()))
    t0 = time.time()
    with mp.get_context('fork').Pool(workers) as pool:
        for _ in pool.imap_unordered(_one, range(n), chunksize=4):
            pass
    if verbose:
        print(f'{n} images en {time.time() - t0:.0f} s')
    return n


def video(frames_dir, out_mp4, fps=FPS, crf=18):
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-framerate', str(fps), '-i', os.path.join(frames_dir, 'f%05d.png'),
                    '-c:v', 'libx264', '-preset', 'medium', '-crf', str(crf), '-pix_fmt', 'yuv420p', out_mp4], check=True)
    return out_mp4


def duration_of(path):
    r = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', path],
                       capture_output=True, text=True)
    return float(r.stdout.strip())


def estimate(duration, size=(1920, 1080), workers=1):
    """Estimation grossière du temps de calcul (s), à annoncer avant de demander l'autorisation."""
    per_s = 10.5 if size[0] >= 1920 else (3.0 if size[0] >= 1280 else 1.2)
    return duration * per_s / max(1, workers)
