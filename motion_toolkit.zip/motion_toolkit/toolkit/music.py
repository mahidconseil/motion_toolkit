"""Musique : écriture note par note, rendu par instruments virtuels, grille exacte (Bible, sections 8 et 10).
Le module ne compose rien : il fournit la mécanique. La composition est écrite pour chaque film.

    sc = Score(bpm=100, meter='6/8')                       # 100 pulsations (noires pointées) par minute
    git = sc.track('guitare_nylon'); sc.note(git, 'E4', bar=0, pos=0, dur=1)
    sc.hit('mains', bar=1, pos=1)                          # pos et dur en pulsations
    sc.render('projet/musique.mp3')                         # + projet/musique_grille.json
"""
import json, os, subprocess

import pretty_midi as pm

SOUNDFONT = '/usr/share/sounds/sf2/FluidR3_GM.sf2'

# Instruments General MIDI (noms lisibles → programme)
INSTRUMENTS = dict(
    piano=0, piano_electrique=4, celesta=8, glockenspiel=9, vibraphone=11, marimba=12, xylophone=13, cloches=14,
    orgue=19, accordeon=21, guitare_nylon=24, guitare_acier=25, guitare_jazz=26, guitare_sourdine=28,
    basse_acoustique=32, basse_doigts=33, basse_mediator=34, contrebasse=43, basse_synth=38,
    violon=40, alto=41, violoncelle=42, cordes_trem=44, pizzicato=45, harpe=46, timbales=47, cordes=48, cordes_lentes=49,
    choeur=52, trompette=56, trombone=57, cor=60, cuivres=61, saxo_alto=65, hautbois=68, clarinette=71,
    flute=73, flute_bec=74, flute_pan=75, sifflet=78, ocarina=79, lead_carre=80, lead_scie=81,
    nappe_chaude=89, nappe_choeur=91, banjo=105, kalimba=108, cornemuse=109, violon_folk=110,
    steel_drum=114, tambour_melodique=116,
)

# Percussions General MIDI (canal 10) → numéro de note
DRUMS = dict(
    grosse_caisse=36, rim=37, caisse_claire=38, mains=39, caisse_claire_2=40,
    tom_basse=41, charleston_ferme=42, tom_basse_2=43, charleston_pied=44, tom_grave=45, charleston_ouvert=46,
    tom_medium=47, tom_aigu=50, cymbale=49, ride=51, cymbale_chinoise=52, tambourin=54, cymbale_splash=55,
    cloche_vache=56, bongo_aigu=60, bongo_grave=61, conga_etouffee=62, conga_aigue=63, conga_grave=64,
    timbale_aigue=65, timbale_grave=66, agogo_aigu=67, agogo_grave=68, cabasa=69, maracas=70,
    claves=75, wood_block_aigu=76, wood_block_grave=77, triangle=81, triangle_etouffe=80, castagnettes=85,
)

SCALES = dict(
    majeure=(0, 2, 4, 5, 7, 9, 11), mineure=(0, 2, 3, 5, 7, 8, 10), dorien=(0, 2, 3, 5, 7, 9, 10),
    mixolydien=(0, 2, 4, 5, 7, 9, 10), pentatonique_majeure=(0, 2, 4, 7, 9), pentatonique_mineure=(0, 3, 5, 7, 10),
)

METERS = {  # pulsations par mesure, subdivisions par pulsation
    '4/4': (4, 2), '3/4': (3, 2), '2/4': (2, 2), '6/8': (2, 3), '12/8': (4, 3),
}

_NAMES = {'C': 0, 'D': 2, 'E': 4, 'F': 5, 'G': 7, 'A': 9, 'B': 11}


def note_number(n):
    """'A4' → 69, 'F#3' → 54, 'Bb2' → 46 ; un entier est renvoyé tel quel."""
    if isinstance(n, int):
        return n
    n = n.strip()
    base = _NAMES[n[0].upper()]
    i = 1
    while i < len(n) and n[i] in '#b':
        base += 1 if n[i] == '#' else -1
        i += 1
    return base + 12 * (int(n[i:]) + 1)


def scale_notes(root, scale, low=None, high=None):
    """Notes MIDI d'une gamme entre low et high. root : 'A' ou 'A2'."""
    r = note_number(root if root[-1].isdigit() else root + '0') % 12
    low, high = note_number(low or 'C2'), note_number(high or 'C6')
    return [n for n in range(low, high + 1) if (n - r) % 12 in SCALES[scale]]


def chord_notes(root, kind='mineur', octave=3):
    """Accord simple : 'majeur', 'mineur', 'sus2', 'sus4', '7', 'm7'."""
    iv = dict(majeur=(0, 4, 7), mineur=(0, 3, 7), sus2=(0, 2, 7), sus4=(0, 5, 7), **{'7': (0, 4, 7, 10), 'm7': (0, 3, 7, 10)})[kind]
    r = note_number(root if root[-1].isdigit() else f'{root}{octave}')
    return [r + i for i in iv]


class Score:
    def __init__(self, bpm=100, meter='6/8', swing=0.0):
        """bpm : pulsations par minute (en 6/8, une pulsation = une noire pointée).
        swing : 0..0,5, retard des contretemps (balancement) appliqué aux positions non entières."""
        self.bpm, self.meter, self.swing = bpm, meter, swing
        self.ppb, self.subs = METERS[meter]
        self.pulse = 60.0 / bpm
        self.bar = self.ppb * self.pulse
        self.midi = pm.PrettyMIDI(initial_tempo=bpm * (self.subs / 2 if self.subs == 3 else 1))
        self.midi.time_signature_changes.append(pm.TimeSignature(*map(int, meter.split('/')), 0))
        self._drums = None
        self.length_bars = 0

    # ---------- temps
    def time(self, bar, pos=0.0):
        """Secondes d'une position (mesure, pulsation dans la mesure)."""
        frac = pos - int(pos)
        if self.swing and frac:
            pos = int(pos) + frac + self.swing * (1 - frac) * frac * 2
        return bar * self.bar + pos * self.pulse

    def grid(self):
        """Grille exacte : pulsations, subdivisions, mesures (secondes et images à 25 i/s)."""
        nb = self.length_bars
        pulses = [round(b * self.bar + p * self.pulse, 4) for b in range(nb) for p in range(self.ppb)]
        subs = [round(b * self.bar + (p + s / self.subs) * self.pulse, 4)
                for b in range(nb) for p in range(self.ppb) for s in range(self.subs)]
        bars = [round(b * self.bar, 4) for b in range(nb + 1)]
        return dict(bpm=self.bpm, meter=self.meter, pulse=round(self.pulse, 5), bar=round(self.bar, 5),
                    duration=round(nb * self.bar, 4), beats=pulses, subdivisions=subs, bars=bars,
                    beat_frames=[int(round(v * 25)) for v in pulses], bar_frames=[int(round(v * 25)) for v in bars])

    # ---------- écriture
    def track(self, name, program=None):
        prog = INSTRUMENTS[name] if program is None else program
        t = pm.Instrument(program=prog, name=name)
        self.midi.instruments.append(t)
        return t

    def _mark(self, bar, pos, dur):
        self.length_bars = max(self.length_bars, int(bar + (pos + dur) / self.ppb + 0.999))

    def note(self, track, pitch, bar, pos=0.0, dur=1.0, vel=90):
        st = self.time(bar, pos)
        track.notes.append(pm.Note(velocity=int(max(1, min(127, vel))), pitch=note_number(pitch),
                                   start=st, end=st + dur * self.pulse))
        self._mark(bar, pos, dur)

    def chord(self, track, pitches, bar, pos=0.0, dur=1.0, vel=80, strum=0.0):
        """Accord ; strum = décalage entre cordes en pulsations (0,02 à 0,05 pour un gratté)."""
        for k, p in enumerate(pitches):
            self.note(track, p, bar, pos + k * strum, dur - k * strum, vel)

    def hit(self, drum, bar, pos=0.0, vel=90, dur=0.25):
        if self._drums is None:
            self._drums = pm.Instrument(program=0, is_drum=True, name='percussions')
            self.midi.instruments.append(self._drums)
        n = DRUMS[drum] if isinstance(drum, str) else drum
        st = self.time(bar, pos)
        self._drums.notes.append(pm.Note(velocity=int(max(1, min(127, vel))), pitch=n, start=st, end=st + dur * self.pulse))
        self._mark(bar, pos, dur)

    def pattern(self, drum, bars, positions, vel=90, accent=None):
        """Motif répété : positions en pulsations dans la mesure ; accent = {position: vélocité}."""
        for b in bars:
            for p in positions:
                self.hit(drum, b, p, (accent or {}).get(p, vel))

    def silence_until(self, bars):
        """Fixe la longueur minimale de la pièce (en mesures)."""
        self.length_bars = max(self.length_bars, bars)

    # ---------- rendu
    def render(self, out_path, gain=0.7, tail=1.2, loudness=-14.0, fade=1.5, soundfont=SOUNDFONT, write_grid=True,
               duration=None):
        """MIDI → FluidSynth → normalisation en deux passes (mesure puis correction linéaire, −14 LUFS / −1 dBTP).
        duration : coupe exacte à la durée du film (fondu de sortie `fade`), même si la pièce ne finit pas sur
        une mesure entière ; par défaut, longueur de la pièce + `tail`.
        Écrit aussi <out>.mid et <out>_grille.json."""
        import re as _re
        base = os.path.splitext(out_path)[0]
        os.makedirs(os.path.dirname(out_path) or '.', exist_ok=True)
        self.midi.write(base + '.mid')
        raw = base + '_brut.wav'
        subprocess.run(['fluidsynth', '-ni', '-g', str(gain), '-r', '48000', '-F', raw, soundfont, base + '.mid'],
                       check=True, capture_output=True)
        dur = duration if duration else self.length_bars * self.bar + tail
        pre = f'apad,atrim=0:{dur:.3f},afade=t=out:st={max(0, dur - fade):.3f}:d={fade}'
        r = subprocess.run(['ffmpeg', '-hide_banner', '-i', raw, '-af',
                            pre + f',loudnorm=I={loudness}:TP=-1:LRA=11:print_format=json', '-f', 'null', '-'],
                           capture_output=True, text=True)
        m = _re.search(r'\{[^{}]*"input_i"[^{}]*\}', r.stderr)
        norm = f'loudnorm=I={loudness}:TP=-1:LRA=11'
        if m:
            js = json.loads(m.group(0))
            norm += (f":measured_I={js['input_i']}:measured_TP={js['input_tp']}:measured_LRA={js['input_lra']}"
                     f":measured_thresh={js['input_thresh']}:offset={js['target_offset']}:linear=true")
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', raw, '-af', f'{pre},{norm},aresample=48000,asetpts=N/SR/TB,apad,atrim=0:{dur:.4f}', '-ar', '48000',
                        '-t', f'{dur:.3f}', *(['-b:a', '192k'] if out_path.endswith('.mp3') else []), out_path],
                       check=True)
        os.remove(raw)
        if write_grid:
            g = self.grid()
            g['fichier_duree'] = round(dur, 3)
            with open(base + '_grille.json', 'w') as f:
                json.dump(g, f)
        return out_path

    def insert_bars(self, at_bar, n):
        """Insère n mesures vides avant la mesure `at_bar` : tout ce qui suit est décalé d'autant (allonger une
        section pour suivre les voix ; bascule, moments clés et logo restent sur des débuts de mesure).
        Les notes qui chevauchent le point d'insertion sont coupées à ce point."""
        t_ins = at_bar * self.bar
        shift = n * self.bar
        for ins in self.midi.instruments:
            for note in ins.notes:
                if note.start >= t_ins - 1e-6:
                    note.start += shift
                    note.end += shift
                elif note.end > t_ins:
                    note.end = t_ins
        self.length_bars += n
        return self


def structure(duration, bpm, meter='6/8', parts=(('probleme', .35), ('bascule', .10), ('resolution', .40), ('signature', .15))):
    """Répartit la durée du film en mesures entières selon les quatre temps (Bible, section 8).
    Renvoie la liste des parties avec mesures de début/fin et instants."""
    ppb = METERS[meter][0]
    bar = ppb * 60.0 / bpm
    total = max(len(parts), round(duration / bar))
    raw = [max(1, round(total * w)) for _, w in parts]
    raw[-1] += total - sum(raw)
    out, b = [], 0
    for (name, _), n in zip(parts, raw):
        out.append(dict(part=name, bar_start=b, bar_end=b + n, t_start=round(b * bar, 3), t_end=round((b + n) * bar, 3)))
        b += n
    return dict(bars=total, bar_seconds=round(bar, 4), duration=round(total * bar, 3), parts=out)
