"""Temps : courbes d'animation, progressions, conversions secondes ↔ images ↔ temps musicaux (Bible, section 5)."""
import math


def clamp(t, a=0.0, b=1.0):
    return max(a, min(b, t))


def lerp(a, b, t):
    return a + (b - a) * t


def prog(t, t0, dur):
    """Progression 0..1 d'une action qui commence à t0 et dure dur secondes."""
    return clamp((t - t0) / dur) if dur > 0 else float(t >= t0)


def ease(t):
    t = clamp(t)
    return t * t * (3 - 2 * t)


def ease_out(t):
    t = clamp(t)
    return 1 - (1 - t) ** 3


def ease_in(t):
    t = clamp(t)
    return t ** 3


def ease_in_out(t):
    t = clamp(t)
    return 4 * t ** 3 if t < .5 else 1 - (-2 * t + 2) ** 3 / 2


def back_out(t, s=1.5):
    """Rebond avec dépassement. Correspondance s → dépassement : 1,17 ≈ 5 %, 1,5 ≈ 8 %, 1,7 ≈ 10 % (préréglages posé, standard, nerveux)."""
    t = clamp(t) - 1
    return 1 + t * t * ((s + 1) * t + s)


def overshoot_param(rebond=0.08):
    """Paramètre s de back_out pour un dépassement donné (0,05 / 0,08 / 0,10 selon le préréglage)."""
    best, err = 1.0, 9
    for k in range(1, 400):
        s = k / 100
        peak = max(back_out(i / 200, s) for i in range(201)) - 1
        if abs(peak - rebond) < err:
            best, err = s, abs(peak - rebond)
    return best


def damped(t, f=7.0, k=7.0):
    """Oscillation amortie sin(2πft)·e^(−kt), nulle avant 0 (à-coups, vibrations)."""
    if t < 0:
        return 0.0
    return math.sin(2 * math.pi * f * t) * math.exp(-k * t)


def half_sine(t):
    """Demi-sinus 0 → 1 → 0 (sautillement)."""
    t = clamp(t)
    return math.sin(math.pi * t)


def window(t, t0, t1, fade_in=0.3, fade_out=0.18):
    """Vie d'un élément affiché de t0 à t1 : 0 → 1 (entrée), 1, puis 1 → 0 (sortie)."""
    if t < t0:
        return 0.0
    if t < t1:
        return clamp((t - t0) / fade_in)
    return 1 - clamp((t - t1) / fade_out)


FPS = 25


def to_frame(t, fps=FPS):
    return int(round(t * fps))


def to_time(frame, fps=FPS):
    return frame / fps


def snap_frame(t, fps=FPS):
    """Arrondit un instant à l'image la plus proche."""
    return round(t * fps) / fps


def scaled(duration, preset='standard'):
    """Durée d'action ajustée au préréglage de dynamisme."""
    from .data import PRESETS
    return duration * PRESETS[preset]['duree']


def stagger(i, step=0.08):
    """Décalage d'un élément i dans une cascade (0,06 à 0,1 s)."""
    return i * step


def keyframes(t, keys, curve=None):
    """Interpole des images clés [(t0, v0), (t1, v1), …] ; valeurs nombres ou tuples.
    curve : fonction 0..1 → 0..1 appliquée à chaque segment (défaut ease_in_out)."""
    curve = curve or ease_in_out
    if t <= keys[0][0]:
        return keys[0][1]
    for (t0, v0), (t1, v1) in zip(keys, keys[1:]):
        if t0 <= t <= t1:
            k = curve((t - t0) / (t1 - t0)) if t1 > t0 else 1
            if isinstance(v0, (tuple, list)):
                return tuple(lerp(a, b, k) for a, b in zip(v0, v1))
            return lerp(v0, v1, k)
    return keys[-1][1]
