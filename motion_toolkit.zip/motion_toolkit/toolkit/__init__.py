"""Socle de plomberie de la Bible « Motion design éditorial » (voir Bible, section 10)."""
__version__ = "2.1"
