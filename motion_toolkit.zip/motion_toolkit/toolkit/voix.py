"""Voix : mesure, préparation, placement des répliques et intelligibilité (Bible, sections 1 et 8).

Les voix arrivent en un fichier par réplique, nommé par plan (p3a_yassine.wav).
    m = mesurer('voix/p3a_yassine.wav')                    # durée parlée, pauses, volume, grave, présence
    preparer('voix/p3a_yassine.wav', 'prep/p3a.wav')        # chaîne de la Bible, −16 LUFS
    pl = placer({'p3a_yassine': 'prep/p3a.wav'}, {'p3a_yassine': 12.4}, 'projet/voix.wav', duree=79.4)
    rapport = intelligibilite('projet/voix.wav', 'projet/musique_attenuee.wav', pl)
"""
import json, os, re, subprocess, tempfile

import numpy as np

SR = 48000


# ---------- lecture / écriture
def lire(path, sr=SR, mono=True):
    """Décode n'importe quel fichier audio en float32 (mono par défaut) via ffmpeg."""
    ch = 1 if mono else 2
    r = subprocess.run(['ffmpeg', '-v', 'error', '-i', path, '-f', 'f32le', '-ac', str(ch), '-ar', str(sr), '-'],
                       capture_output=True, check=True)
    y = np.frombuffer(r.stdout, np.float32).copy()
    return (y if mono else y.reshape(-1, 2)), sr


def ecrire(path, y, sr=SR):
    """Écrit un WAV 24 bits (mono ou stéréo)."""
    y = np.asarray(y, np.float32)
    ch = 1 if y.ndim == 1 else y.shape[1]
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'f32le', '-ac', str(ch), '-ar', str(sr), '-i', '-',
                    '-c:a', 'pcm_s24le', path], input=y.tobytes(), check=True)
    return path


def _lufs(path):
    r = subprocess.run(['ffmpeg', '-nostats', '-i', path, '-af', 'loudnorm=print_format=json', '-f', 'null', '-'],
                       capture_output=True, text=True)
    m = re.search(r'\{[^{}]*"input_i"[^{}]*\}', r.stderr)
    return json.loads(m.group(0)) if m else None


def _rms_db(x):
    return 20 * np.log10(np.sqrt(np.mean(np.square(x))) + 1e-12)


def _bands(y, sr):
    """Part de l'énergie sous 250 Hz (dB relatifs) et présence 2-5 kHz (dB relatifs)."""
    spec = np.abs(np.fft.rfft(y * np.hanning(len(y)))) ** 2 if len(y) < sr * 30 else None
    if spec is None:
        seg = y[: sr * 30]
        spec = np.abs(np.fft.rfft(seg * np.hanning(len(seg)))) ** 2
        n = len(seg)
    else:
        n = len(y)
    f = np.fft.rfftfreq(n, 1 / sr)
    tot = spec[(f > 60) & (f < 12000)].sum() + 1e-20
    grave = 10 * np.log10(spec[(f > 60) & (f < 250)].sum() / tot + 1e-20)
    presence = 10 * np.log10(spec[(f > 2000) & (f < 5000)].sum() / tot + 1e-20)
    return grave, presence


# ---------- mesure
def pauses(y, sr=SR, seuil_db=-40, min_pause=0.25):
    """Pauses internes (début, fin) en secondes, hors silences de tête et de queue."""
    hop = int(sr * 0.01)
    fr = np.array([_rms_db(y[i:i + hop]) for i in range(0, len(y) - hop, hop)])
    ref = np.percentile(fr, 95)
    voix = fr > ref + seuil_db
    if not voix.any():
        return []
    a, b = np.argmax(voix), len(voix) - np.argmax(voix[::-1])
    out, start = [], None
    for i in range(a, b):
        if not voix[i] and start is None:
            start = i
        elif voix[i] and start is not None:
            if (i - start) * 0.01 >= min_pause:
                out.append((round(start * 0.01, 3), round(i * 0.01, 3)))
            start = None
    return out


def mesurer(path):
    """Mesures d'une réplique : durée totale, durée parlée, pauses internes, LUFS, dynamique, grave, présence."""
    y, sr = lire(path)
    hop = int(sr * 0.05)
    fr = np.array([_rms_db(y[i:i + hop]) for i in range(0, max(1, len(y) - hop), hop)])
    actifs = fr[fr > np.percentile(fr, 95) - 40]
    ps = pauses(y, sr)
    grave, pres = _bands(y, sr)
    lu = _lufs(path)
    tete = next((i for i, v in enumerate(fr) if v > np.percentile(fr, 95) - 40), 0) * 0.05
    queue = next((i for i, v in enumerate(fr[::-1]) if v > np.percentile(fr, 95) - 40), 0) * 0.05
    duree = len(y) / sr
    return dict(fichier=os.path.basename(path), duree=round(duree, 3),
                duree_parlee=round(duree - tete - queue - sum(b - a for a, b in ps), 3),
                tete=round(tete, 3), queue=round(queue, 3), pauses=ps,
                lufs=float(lu['input_i']) if lu else None,
                dynamique_db=round(float(np.percentile(actifs, 95) - np.percentile(actifs, 10)), 1) if len(actifs) else None,
                grave_db=round(float(grave), 1), presence_db=round(float(pres), 1))


# ---------- préparation
def resserrer(y, sr=SR, max_pause=0.5, garde=0.45, seuil_db=-40):
    """Ramène chaque pause interne de plus de max_pause à `garde` secondes (fondus de 10 ms)."""
    ps = [(a, b) for a, b in pauses(y, sr, seuil_db) if b - a > max_pause]
    if not ps:
        return y
    out, cur, f = [], 0, int(sr * 0.01)
    for a, b in ps:
        cut_a = int((a + garde / 2) * sr)
        cut_b = int((b - garde / 2) * sr)
        seg = y[cur:cut_a].copy()
        if len(seg) > f:
            seg[-f:] *= np.linspace(1, 0, f)
        out.append(seg)
        cur = cut_b
    tail = y[cur:].copy()
    if len(tail) > f:
        tail[:f] *= np.linspace(0, 1, f)
    out.append(tail)
    return np.concatenate(out)


def chaine(grave_db, presence_db, telephone=False):
    """Chaîne ffmpeg de préparation (Bible, section 8), réglée d'après les mesures de la réplique."""
    if telephone:
        return ('highpass=f=300,lowpass=f=3400,acompressor=threshold=-22dB:ratio=3:attack=5:release=80:makeup=4,'
                'dynaudnorm=f=150:g=11:p=0.9:m=4:s=8')
    g_cut = 6 if grave_db > -3 else (3 if grave_db > -6 else 0)
    p_up = min(6, max(0, -12 - presence_db))
    return ('highpass=f=90,'
            f'equalizer=f=180:t=o:w=1.2:g=-{g_cut},'
            f'equalizer=f=3200:t=o:w=1.4:g={p_up:.1f},'
            'acompressor=threshold=-24dB:ratio=3:attack=6:release=90:makeup=3,'
            'dynaudnorm=f=150:g=11:p=0.9:m=4:s=8,'
            'agate=threshold=0.035:ratio=2.5:attack=4:release=140:range=0.15')


def preparer(path, out_path, telephone=False, cible=-16.0, max_pause=0.5, garde=0.45, vitesse=1.0):
    """Prépare une réplique : pauses resserrées, chaîne de la Bible (ou filtre téléphone), puis mise au niveau
    (−16 LUFS) et limiteur. Le filtre téléphone est appliqué AVANT la mise au niveau.
    vitesse : accélération sans changer la hauteur (teaser : 1,15 au plus). Renvoie les mesures avant/après."""
    avant = mesurer(path)
    y, sr = lire(path)
    y = resserrer(y, sr, max_pause, garde)
    with tempfile.TemporaryDirectory() as tmp:
        a = ecrire(os.path.join(tmp, 'a.wav'), y, sr)
        filt = chaine(avant['grave_db'], avant['presence_db'], telephone)
        if abs(vitesse - 1) > 1e-3:
            filt += f',atempo={min(2.0, max(0.5, vitesse)):.3f}'
        b = os.path.join(tmp, 'b.wav')
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', a, '-af', filt, '-ar', str(sr), '-c:a', 'pcm_s24le', b],
                       check=True)
        os.makedirs(os.path.dirname(out_path) or '.', exist_ok=True)
        gain = 0.0
        for _ in range(3):                       # mise au niveau itérative (le limiteur décale la mesure)
            subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', b, '-af', f'volume={gain:.2f}dB,alimiter=limit=0.89',
                            '-ar', str(sr), '-c:a', 'pcm_s24le', out_path], check=True)
            lu = _lufs(out_path)
            if not lu or lu['input_i'] in ('-inf', None):
                break
            err = cible - float(lu['input_i'])
            if abs(err) < 0.3:
                break
            gain += err
    apres = mesurer(out_path)
    return dict(avant=avant, apres=apres, chaine=filt)


# ---------- placement
def placer(fichiers, debuts, out_path, duree, sr=SR, json_path=None):
    """Assemble les répliques sur une piste unique.
    fichiers : {nom: chemin} ; debuts : {nom: instant en s}. Renvoie {nom: {debut, fin, fichier}} et
    l'écrit en JSON (json_path, par défaut à côté de out_path) pour l'enveloppe de la musique et les bouches."""
    piste = np.zeros(int(duree * sr) + sr, np.float32)
    pl = {}
    for nom, chemin in fichiers.items():
        y, _ = lire(chemin, sr)
        i = int(debuts[nom] * sr)
        j = min(len(piste), i + len(y))
        piste[i:j] += y[: j - i]
        pl[nom] = dict(debut=round(debuts[nom], 3), fin=round(debuts[nom] + len(y) / sr, 3), fichier=chemin)
    ecrire(out_path, piste[: int(duree * sr)], sr)
    with open(json_path or os.path.splitext(out_path)[0] + '_placement.json', 'w') as f:
        json.dump(pl, f, ensure_ascii=False, indent=1)
    chev = [(a, b) for a in pl for b in pl if a < b and pl[a]['debut'] < pl[b]['fin'] and pl[b]['debut'] < pl[a]['fin']]
    if chev:
        print('attention, répliques qui se chevauchent :', chev)
    return pl


def courbe_bouche(path, fps=25, plancher_db=-45, lissage=2):
    """Ouverture de bouche 0..1 image par image, d'après le volume de la réplique."""
    y, sr = lire(path)
    hop = int(sr / fps)
    db = np.array([_rms_db(y[i:i + hop]) for i in range(0, len(y), hop)])
    pic = np.percentile(db, 98)
    v = np.clip((db - plancher_db) / max(1e-6, pic - plancher_db), 0, 1)
    if lissage > 1:
        v = np.convolve(v, np.ones(lissage) / lissage, mode='same')
    return [round(float(x), 3) for x in v]


def bouche_a(t, placement, courbes, fps=25):
    """Ouverture de bouche à l'instant t pour un personnage : courbes = {nom: courbe}, placement des répliques.
    Renvoie None hors parole (bouche au repos)."""
    for nom, p in placement.items():
        if nom in courbes and p['debut'] <= t < p['fin']:
            k = int((t - p['debut']) * fps)
            c = courbes[nom]
            return c[k] if k < len(c) else 0.0
    return None


# ---------- intelligibilité
def _bande(y, sr, lo=1000, hi=5000):
    sos_f = np.fft.rfftfreq(len(y), 1 / sr)
    Y = np.fft.rfft(y)
    Y[(sos_f < lo) | (sos_f > hi)] = 0
    return np.fft.irfft(Y, len(y))


def intelligibilite(voix_path, musique_path, placement, seuil_db=10.0, sr=SR):
    """Rapport voix / musique (déjà atténuée) dans la bande 1-5 kHz, réplique par réplique (Bible : ≥ +10 dB).
    Contrôle aussi la première syllabe du film (0,4 s). Renvoie (rapport, alertes)."""
    v, _ = lire(voix_path, sr)
    m, _ = lire(musique_path, sr)
    n = min(len(v), len(m))
    rep, alertes = {}, []
    for nom, p in sorted(placement.items(), key=lambda kv: kv[1]['debut']):
        a, b = int(p['debut'] * sr), min(n, int(p['fin'] * sr))
        if b - a < sr * 0.1:
            continue
        vv, mm = _bande(v[a:b], sr), _bande(m[a:b], sr)
        hop = int(sr * 0.05)
        actif = [i for i in range(0, len(vv) - hop, hop) if _rms_db(vv[i:i + hop]) > _rms_db(vv) - 15]
        if not actif:
            continue
        rv = _rms_db(np.concatenate([vv[i:i + hop] for i in actif]))
        rm = _rms_db(np.concatenate([mm[i:i + hop] for i in actif]))
        r = round(float(rv - rm), 1)
        rep[nom] = r
        if r < seuil_db:
            alertes.append(f'{nom} : voix à +{r} dB au-dessus de la musique (1-5 kHz), seuil +{seuil_db} dB')
    if placement:
        nom0, p0 = min(placement.items(), key=lambda kv: kv[1]['debut'])
        a = int(p0['debut'] * sr)
        hop = int(sr * 0.01)
        ref = _rms_db(v[a:min(n, int(p0['fin'] * sr))])
        while a + hop < n and _rms_db(v[a:a + hop]) < ref - 20:      # saute le silence de tête du fichier
            a += hop
        b = min(n, a + int(0.4 * sr))
        if b > a:
            r0 = round(float(_rms_db(_bande(v[a:b], sr)) - _rms_db(_bande(m[a:b], sr))), 1)
            rep['_premiere_syllabe'] = r0
            if r0 < seuil_db:
                alertes.append(f'première syllabe ({nom0}) à +{r0} dB seulement')
    return rep, alertes
