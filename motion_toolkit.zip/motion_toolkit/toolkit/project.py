"""État du projet : projet.json, découpage → ligne de temps, recherche du plan courant (Bible, sections 1 et 10).

    p = Project('projet/projet.json')
    p.data['plans'] = [{'id': 'P1', 'duree': 3.2, ...}, ...]
    p.timeline(grid=grille, snap='beats')       # calcule debut/fin de chaque plan, calés sur la musique
    plan, t_local, i = p.shot_at(t)
"""
import json, os


class Project:
    def __init__(self, path='projet/projet.json'):
        self.path = path
        self.data = json.load(open(path)) if os.path.exists(path) else dict(brief={}, plans=[], decisions=[])

    def save(self):
        os.makedirs(os.path.dirname(self.path) or '.', exist_ok=True)
        with open(self.path, 'w') as f:
            json.dump(self.data, f, ensure_ascii=False, indent=1)
        return self.path

    def note(self, text):
        """Consigne une décision validée par l'utilisateur (reprise dans une autre conversation)."""
        self.data.setdefault('decisions', []).append(text)

    def timeline(self, grid=None, snap='beats', start=0.0):
        """Calcule debut/fin des plans à partir de leurs durées ; avec une grille, chaque coupe est calée
        sur le temps (ou la mesure) le plus proche."""
        t = start
        pts = (grid or {}).get(snap) or []
        for p in self.data['plans']:
            p['debut'] = round(t, 4)
            end = t + p['duree']
            if pts:
                end = min(pts + [grid['duration']], key=lambda v: abs(v - end))
                if end <= t:
                    end = next((v for v in pts if v > t), t + p['duree'])
            p['fin'] = round(end, 4)
            p['duree'] = round(end - t, 4)
            t = end
        self.data['duree_totale'] = round(t, 4)
        return self.data['plans']

    def shot_at(self, t):
        for i, p in enumerate(self.data['plans']):
            if p['debut'] <= t < p['fin']:
                return p, t - p['debut'], i
        last = self.data['plans'][-1]
        return last, t - last['debut'], len(self.data['plans']) - 1
