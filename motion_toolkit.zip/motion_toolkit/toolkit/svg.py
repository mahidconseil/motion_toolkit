"""SVG sûr : échappement, identifiants uniques, transformations, enveloppe de rendu (Bible, section 10)."""
import itertools
from html import escape as _esc

from .data import DESIGN

_ids = itertools.count(1)


def esc(text):
    """Échappe &, <, >, guillemets : obligatoire pour tout texte inséré dans le SVG."""
    return _esc(str(text), quote=True)


def uid(prefix='id'):
    """Identifiant unique (masques, dégradés) : évite les collisions entre plans et personnages."""
    return f'{prefix}{next(_ids)}'


def f(v, nd=2):
    """Nombre formaté court."""
    return f'{v:.{nd}f}'.rstrip('0').rstrip('.') if isinstance(v, float) else str(v)


def g(content, translate=None, scale=None, rotate=None, origin=None, opacity=None):
    """Groupe transformé. rotate et scale autour de origin=(x, y) si fourni."""
    tr = []
    if translate:
        tr.append(f'translate({f(translate[0])},{f(translate[1])})')
    if origin and (scale is not None or rotate):
        tr.append(f'translate({f(origin[0])},{f(origin[1])})')
    if rotate:
        tr.append(f'rotate({f(rotate)})')
    if scale is not None:
        sx, sy = scale if isinstance(scale, (tuple, list)) else (scale, scale)
        tr.append(f'scale({f(sx, 4)},{f(sy, 4)})')
    if origin and (scale is not None or rotate):
        tr.append(f'translate({f(-origin[0])},{f(-origin[1])})')
    attrs = f' transform="{" ".join(tr)}"' if tr else ''
    if opacity is not None and opacity < 1:
        attrs += f' opacity="{max(0.0, opacity):.3f}"'
    return f'<g{attrs}>{content}</g>'


def wrap(body, size=(1920, 1080), design=DESIGN, bg='#FFFFFF', defs=''):
    """Document SVG complet : contenu composé dans le repère `design`, rendu à `size`."""
    w, h = size
    d = f'<defs>{defs}</defs>' if defs else ''
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {design[0]} {design[1]}">{d}'
            f'<rect width="{design[0]}" height="{design[1]}" fill="{bg}"/>{body}</svg>')


def path_length(points):
    """Longueur d'une polyligne [(x, y), …] (pour les tracés progressifs)."""
    from math import hypot
    return sum(hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(points, points[1:]))


def draw_on(d, length, progress, **attrs):
    """Chemin tracé progressivement (progress 0..1) via stroke-dasharray."""
    a = ' '.join(f'{k.replace("_", "-")}="{v}"' for k, v in attrs.items())
    off = length * (1 - max(0.0, min(1.0, progress)))
    return f'<path d="{d}" fill="none" stroke-dasharray="{length:.1f}" stroke-dashoffset="{off:.1f}" {a}/>'
