"""Sons : primitives de synthèse et placement sur une ligne de temps (Bible, sections 8 et 10).
Les générateurs pop / click / swoosh / ding sont des points de départ paramétrables, à ajuster pour chaque film.

    tl = Timeline(duree)
    tl.add(pop(700), t=1.24)                  # pastille qui apparaît
    for k in range(12): tl.add(click(), t=3.0 + k / 18)
    tl.write('projet/sons.wav')
"""
import wave

import numpy as np

SR = 44100


def envelope(n, a=0.005, d=0.05, s=0.0, r=0.05, sr=SR):
    """Enveloppe ADSR (durées en secondes, s = niveau de maintien) sur n échantillons."""
    A, D, R = a * sr, d * sr, r * sr
    xs = [0, A, A + D, max(A + D, n - R), n]
    xs = np.maximum.accumulate(np.minimum(xs, n))
    return np.interp(np.arange(n), xs, [0, 1, s, s, 0])


def tone(freq, dur, wave_='sine', sr=SR):
    t = np.arange(int(dur * sr)) / sr
    ph = 2 * np.pi * (np.cumsum(np.full(len(t), freq) if np.isscalar(freq) else freq) / sr)
    if wave_ == 'sine':
        return np.sin(ph)
    if wave_ == 'triangle':
        return 2 / np.pi * np.arcsin(np.sin(ph))
    if wave_ == 'square':
        return np.sign(np.sin(ph)) * 0.6
    raise ValueError(wave_)


def sweep(f0, f1, dur, sr=SR, curve='exp'):
    """Fréquence instantanée glissant de f0 à f1 (à passer à tone)."""
    n = int(dur * sr)
    return np.geomspace(f0, f1, n) if curve == 'exp' else np.linspace(f0, f1, n)


def noise(dur, sr=SR, seed=0):
    return np.random.default_rng(seed).uniform(-1, 1, int(dur * sr))


def lowpass(x, cutoff, sr=SR):
    """Passe-bas à un pôle ; cutoff peut être un tableau (balayage)."""
    c = np.broadcast_to(np.asarray(cutoff, float), x.shape)
    a = np.exp(-2 * np.pi * c / sr)
    y = np.zeros_like(x)
    prev = 0.0
    for i in range(len(x)):
        prev = (1 - a[i]) * x[i] + a[i] * prev
        y[i] = prev
    return y


def highpass(x, cutoff, sr=SR):
    return x - lowpass(x, cutoff, sr)


def normalize(x, peak=0.9):
    m = np.max(np.abs(x)) or 1.0
    return x / m * peak


# ---------- points de départ
def pop(freq=650, dur=0.09):
    x = tone(sweep(freq * 1.6, freq, dur), dur)
    return normalize(x * envelope(len(x), 0.002, dur * 0.6, 0, dur * 0.3)) * 0.8


def click(freq=2400, dur=0.025, seed=0):
    x = highpass(noise(dur, seed=seed), 1500) * 0.6 + tone(freq, dur) * 0.4
    return normalize(x * envelope(len(x), 0.0005, dur * 0.5, 0, dur * 0.4)) * 0.5


def swoosh(dur=0.35, up=True, seed=1):
    n = noise(dur, seed=seed)
    cut = np.geomspace(400, 5000, len(n)) if up else np.geomspace(5000, 400, len(n))
    x = lowpass(n, cut)
    return normalize(x * envelope(len(x), dur * 0.45, dur * 0.1, 0.6, dur * 0.45)) * 0.7


def ding(freq=1320, dur=0.8):
    x = tone(freq, dur) + 0.4 * tone(freq * 2.01, dur) + 0.2 * tone(freq * 3.02, dur)
    return normalize(x * envelope(len(x), 0.002, 0.1, 0.25, dur * 0.8)) * 0.6


class Timeline:
    def __init__(self, duration, sr=SR):
        self.sr = sr
        self.buf = np.zeros(int(duration * sr) + sr)

    def add(self, sound, t, gain_db=0.0, pan=0.0):
        i = int(t * self.sr)
        if i >= len(self.buf):
            return
        s = sound[:len(self.buf) - i] * (10 ** (gain_db / 20))
        self.buf[i:i + len(s)] += s

    def write(self, path, peak=0.9):
        x = self.buf
        m = np.max(np.abs(x))
        if m > peak:
            x = x / m * peak
        data = (np.clip(x, -1, 1) * 32767).astype(np.int16)
        with wave.open(path, 'wb') as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(self.sr)
            w.writeframes(data.tobytes())
        return path
