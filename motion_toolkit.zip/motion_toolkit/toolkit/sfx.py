"""Sons : primitives de synthèse et placement sur une ligne de temps (Bible, sections 8 et 10).
Points de départ paramétrables, à ajuster pour chaque film : pop, click, swoosh, ding, froissement, vibration,
sonnerie, tampon, boom, impact (fin coupée net), nappe (montée de tension), tictac (qui accélère).

    tl = Timeline(duree)
    tl.add(pop(700), t=1.24)                  # pastille qui apparaît
    for k in range(12): tl.add(click(), t=3.0 + k / 18)
    tl.write('projet/sons.wav')
"""
import wave

import numpy as np

SR = 44100


def envelope(n, a=0.005, d=0.05, s=0.0, r=0.05, sr=SR):
    """Enveloppe ADSR (durées en secondes, s = niveau de maintien) sur n échantillons."""
    A, D, R = a * sr, d * sr, r * sr
    xs = [0, A, A + D, max(A + D, n - R), n]
    xs = np.maximum.accumulate(np.minimum(xs, n))
    return np.interp(np.arange(n), xs, [0, 1, s, s, 0])


def tone(freq, dur, wave_='sine', sr=SR):
    t = np.arange(int(dur * sr)) / sr
    ph = 2 * np.pi * (np.cumsum(np.full(len(t), freq) if np.isscalar(freq) else freq) / sr)
    if wave_ == 'sine':
        return np.sin(ph)
    if wave_ == 'triangle':
        return 2 / np.pi * np.arcsin(np.sin(ph))
    if wave_ == 'square':
        return np.sign(np.sin(ph)) * 0.6
    raise ValueError(wave_)


def sweep(f0, f1, dur, sr=SR, curve='exp'):
    """Fréquence instantanée glissant de f0 à f1 (à passer à tone)."""
    n = int(dur * sr)
    return np.geomspace(f0, f1, n) if curve == 'exp' else np.linspace(f0, f1, n)


def noise(dur, sr=SR, seed=0):
    return np.random.default_rng(seed).uniform(-1, 1, int(dur * sr))


def lowpass(x, cutoff, sr=SR):
    """Passe-bas à un pôle ; cutoff peut être un tableau (balayage)."""
    c = np.broadcast_to(np.asarray(cutoff, float), x.shape)
    a = np.exp(-2 * np.pi * c / sr)
    y = np.zeros_like(x)
    prev = 0.0
    for i in range(len(x)):
        prev = (1 - a[i]) * x[i] + a[i] * prev
        y[i] = prev
    return y


def highpass(x, cutoff, sr=SR):
    return x - lowpass(x, cutoff, sr)


def normalize(x, peak=0.9):
    m = np.max(np.abs(x)) or 1.0
    return x / m * peak


# ---------- points de départ
def pop(freq=650, dur=0.09):
    x = tone(sweep(freq * 1.6, freq, dur), dur)
    return normalize(x * envelope(len(x), 0.002, dur * 0.6, 0, dur * 0.3)) * 0.8


def click(freq=2400, dur=0.025, seed=0):
    x = highpass(noise(dur, seed=seed), 1500) * 0.6 + tone(freq, dur) * 0.4
    return normalize(x * envelope(len(x), 0.0005, dur * 0.5, 0, dur * 0.4)) * 0.5


def swoosh(dur=0.35, up=True, seed=1):
    n = noise(dur, seed=seed)
    cut = np.geomspace(400, 5000, len(n)) if up else np.geomspace(5000, 400, len(n))
    x = lowpass(n, cut)
    return normalize(x * envelope(len(x), dur * 0.45, dur * 0.1, 0.6, dur * 0.45)) * 0.7


def ding(freq=1320, dur=0.8):
    x = tone(freq, dur) + 0.4 * tone(freq * 2.01, dur) + 0.2 * tone(freq * 3.02, dur)
    return normalize(x * envelope(len(x), 0.002, 0.1, 0.25, dur * 0.8)) * 0.6


def froissement(dur=0.16, seed=2):
    """Papier froissé : bruit aigu filtré, granuleux."""
    x = highpass(noise(dur, seed=seed), 2500)
    grain = (np.random.default_rng(seed + 1).random(len(x)) > 0.6).astype(float)
    return normalize(x * (0.4 + 0.6 * grain) * envelope(len(x), 0.005, dur * 0.4, 0.4, dur * 0.4)) * 0.45


def vibration(dur=0.5, freq=150):
    """Téléphone qui vibre : carré à 150 Hz modulé par impulsions, filtré."""
    t = np.arange(int(dur * SR)) / SR
    x = lowpass(tone(freq, dur, 'square'), 600)
    mod = (np.sin(2 * np.pi * 12 * t) > -0.2).astype(float)
    return normalize(x * mod * envelope(len(x), 0.01, 0.05, 0.9, 0.05)) * 0.5


def sonnerie(dur=1.2, f1=880, f2=1175, rate=10):
    """Sonnerie de téléphone : deux tons triangle alternés."""
    t = np.arange(int(dur * SR)) / SR
    alt = (np.floor(t * rate) % 2).astype(float)
    x = tone(f1, dur, 'triangle') * (1 - alt) + tone(f2, dur, 'triangle') * alt
    gate = (t % 0.6 < 0.4).astype(float)
    return normalize(x * gate * envelope(len(x), 0.005, 0.02, 0.9, 0.05)) * 0.45


def tampon(dur=0.22, seed=3):
    """Coup de tampon : bruit grave et ton à 90 Hz."""
    x = lowpass(noise(dur, seed=seed), 900) * 0.6 + tone(sweep(110, 75, dur), dur) * 0.8
    return normalize(x * envelope(len(x), 0.001, dur * 0.3, 0.1, dur * 0.5)) * 0.8


def boom(dur=0.9):
    """Boom grave : balayage de 95 à 38 Hz."""
    x = tone(sweep(95, 38, dur), dur)
    return normalize(x * envelope(len(x), 0.004, dur * 0.4, 0.3, dur * 0.55)) * 0.9


def impact(dur=0.45, seed=4):
    """Impact du teaser : bruit et balayage de 70 à 28 Hz, fin coupée net."""
    x = lowpass(noise(dur, seed=seed), 1200) * 0.5 + tone(sweep(70, 28, dur), dur)
    env = envelope(len(x), 0.002, dur * 0.25, 0.7, 0.0)
    env[-int(0.004 * SR):] = 0                         # coupure nette
    return normalize(x * env) * 0.9


def nappe(dur=3.0, f0=55, seed=5):
    """Montée de tension : grave qui enfle et souffle qui monte."""
    x = tone(sweep(f0, f0 * 1.5, dur, curve='lin'), dur) * 0.8 + 0.3 * tone(f0 * 2, dur)
    souffle = lowpass(noise(dur, seed=seed), np.geomspace(300, 6000, int(dur * SR))) * np.linspace(0, 1, int(dur * SR))
    env = np.linspace(0, 1, int(dur * SR)) ** 1.5
    return normalize((x + 0.6 * souffle) * env) * 0.7


def tictac(dur=3.0, debut=0.5, fin=0.12, f=3200):
    """Tic-tac qui accélère (menace du teaser) : intervalle de `debut` à `fin` secondes."""
    out = np.zeros(int(dur * SR) + SR)
    t, k = 0.0, 0
    while t < dur:
        c = click(freq=f if k % 2 == 0 else f * 0.8, seed=k)
        i = int(t * SR)
        out[i:i + len(c)] += c
        t += debut + (fin - debut) * (t / dur)
        k += 1
    return out[: int(dur * SR)]


class Timeline:
    def __init__(self, duration, sr=SR):
        self.sr = sr
        self.buf = np.zeros(int(duration * sr) + sr)

    def add(self, sound, t, gain_db=0.0, pan=0.0):
        i = int(t * self.sr)
        if i >= len(self.buf):
            return
        s = sound[:len(self.buf) - i] * (10 ** (gain_db / 20))
        self.buf[i:i + len(s)] += s

    def write(self, path, peak=0.9):
        x = self.buf
        m = np.max(np.abs(x))
        if m > peak:
            x = x / m * peak
        data = (np.clip(x, -1, 1) * 32767).astype(np.int16)
        with wave.open(path, 'wb') as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(self.sr)
            w.writeframes(data.tobytes())
        return path
