"""Rig articulé (personnages propriétaires livrés en SVG + manifest + poses + cycles), Bible sections 3, 5 et 10.

Format d'entrée (exemple : Kabour) :
- un SVG par vue, articulations = <g id data-pivot="x,y" data-parent> pilotées par leur seul transform ;
- <vue>.manifest.json : articulations (pivot, parent, zone, bornes), zones, visage (paupières, bouches par
  phonème × humeur, bouches d'expression, moustache réglée par bouche, sourcils, iris), chemins déformables,
  correspondance des phonèmes (latin et arabe), sol, pieds ;
- poses.json : poses (angles par zone, oscillations), expressions (états du visage par famille de visage — le manifest
  d'une vue indique sa `famille_visage`, ex. assis_face et tailleur → face — et tête additive) ;
- cycles (walk.json…) : échantillons d'angles par zone, déplacement du corps, chemins déformés.

    k = Personnage('kits/kabour', vues={'face': 'kabour_face.manifest.json', 'profil': 'kabour_profil.manifest.json'},
                   poses='poses.json', cycles={'marche': 'walk.json'}, seed=1)
    j = k.jeu('profil')                          # une ligne de temps par plan
    j.marche('marche', 0.4, 4.2)
    j.expression('content', 0.5)
    j.pose('montre_devant', 2.4, 3.6)
    j.parole(1.0, 'voix/p1a.wav', texte='السلام عليكم')
    svg = j.placer(j.image(t), x=300, sol=684, echelle=k.echelle(380))   # pieds en (x, sol), regarde à droite
    (echelle commune à toutes les vues ; hauteur= place une vue isolée d'après sa propre hauteur)

Le moteur ajoute la vie : respiration, clignements, petits mouvements de regard, balancement de tête et de bras,
pompon qui suit la tête. Tout est déterministe (même t → même image), compatible avec render.frames.
"""
import copy, itertools, json, math, os, random, re
import xml.etree.ElementTree as ET

from .timing import clamp, ease, ease_in_out, lerp

NS = 'http://www.w3.org/2000/svg'
XL = 'http://www.w3.org/1999/xlink'
ET.register_namespace('', NS)
ET.register_namespace('xlink', XL)
_inst = itertools.count(1)
_NUM = re.compile(r'-?\d*\.?\d+(?:[eE][-+]?\d+)?')
FPS = 25


def _f(v):
    return ('%.3f' % v).rstrip('0').rstrip('.') if isinstance(v, float) else str(v)


def interp_path(d0, d1, k):
    """Interpole deux chemins de même structure (mêmes commandes, même nombre de points)."""
    if k <= 0 or d0 == d1:
        return d0
    if k >= 1:
        return d1
    n0, n1 = _NUM.findall(d0), _NUM.findall(d1)
    if len(n0) != len(n1):
        return d0 if k < 0.5 else d1
    it = iter(lerp(float(a), float(b), k) for a, b in zip(n0, n1))
    return _NUM.sub(lambda m: _f(next(it)), d0)


class Vue:
    """Une vue d'un rig articulé : SVG + manifest, chargés une fois, rendus par mise à jour d'attributs."""

    def __init__(self, dossier, manifest):
        self.m = json.load(open(os.path.join(dossier, manifest)))
        self.nom = self.m['vue']
        self.tree = ET.parse(os.path.join(dossier, self.m['fichier']))
        self.root = self.tree.getroot()
        self._prefix_ids(f'ra{next(_inst)}_')
        self.joints = {a['id']: a for a in self.m['articulations']}
        self.zones = self.m['zones']
        self.zone_of = {j: z for z, js in self.zones.items() for j in js}
        V = self.m.get('visage') or {}
        self.face = bool(V)
        self.B = V.get('bouches') or {'repos': None, 'tous': [], 'ouverture': {'MBP': 0.0}, 'motif_id': '{phoneme}',
                                      'repos_par_humeur': {}, 'humeurs': ['neutre']}
        self.mouths = [x for x in [self.B['repos']] + [x for x in self.B['tous'] if x != self.B['repos']] if x]
        self.lids = (V.get('paupieres') or {}).get('etats', {})
        self.brows = V.get('sourcils') or {'ids': [], 'pivots': {}}
        self.iris = V.get('iris') or {'ids': [], 'amplitude': [0, 0]}
        self.must = V.get('moustache') or {'id': None, 'par_bouche': {}}
        self.deform = self.m.get('chemins_deformables', {}).get('ids', [])
        self.neutral_d = {p: self.el[p].get('d') for p in self.deform if p in self.el}
        self.sol = self.m['sol_y']
        self.pieds = self.m['pieds']
        vb = self.root.get('viewBox')
        self.repere = self.m.get('repere') or ([float(v) for v in vb.split()[2:]] if vb else [447, 447])
        self.top = self._top_y()

    def _prefix_ids(self, p):
        """Préfixe tous les identifiants (et leurs références) pour éviter les collisions dans une scène."""
        self.el = {}
        for e in self.root.iter():
            i = e.get('id')
            if i:
                self.el[i] = e
                e.set('id', p + i)
        ref = re.compile(r'url\(#([^)]+)\)')
        for e in self.root.iter():
            for k, v in list(e.attrib.items()):
                if 'url(#' in v:
                    e.set(k, ref.sub(lambda m: f'url(#{p}{m.group(1)})', v))
                elif k in ('href', f'{{{XL}}}href') and v.startswith('#'):
                    e.set(k, '#' + p + v[1:])

    def _top_y(self):
        """Haut du personnage (sommet du bonnet) mesuré sur un rendu neutre, pour placer par hauteur."""
        try:
            import io, cairosvg
            from PIL import Image
            w, h = int(self.repere[0]), int(self.repere[1])
            png = cairosvg.svg2png(bytestring=ET.tostring(self.root), output_width=w, output_height=h)
            a = Image.open(io.BytesIO(png)).split()[-1].point(lambda v: 255 if v > 20 else 0)
            bb = a.getbbox()
            return float(bb[1]) if bb else 0.0
        except Exception:
            return 0.0

    # ---------- application d'un état
    def appliquer(self, etat):
        """etat : angles {articulation: degrés}, racine (dx, dy), respiration (échelle verticale du buste),
        paupieres, bouche (id), sourcils {id: (dx, dy, rot)}, iris (gx, gy), chemins {id: d}."""
        ang = etat.get('angles', {})
        dx, dy = etat.get('racine', (0.0, 0.0))
        resp = etat.get('respiration', 1.0)
        for jid, a in self.joints.items():
            if a.get('zone') == 'visage' or jid not in self.el:
                continue
            px, py = a['pivot']
            g = ang.get(jid, 0.0)
            if a['parent'] is None:
                tf = f'translate({_f(dx)} {_f(dy)}) rotate({_f(g)} {_f(px)} {_f(py)})'
            else:
                tf = f'translate(0 0) rotate({_f(g)} {_f(px)} {_f(py)})'
                if jid == 'torso' and abs(resp - 1) > 1e-5:
                    tf += f' translate({_f(px)} {_f(py)}) scale(1 {resp:.4f}) translate({_f(-px)} {_f(-py)})'
            self.el[jid].set('transform', tf)
        # paupières
        choix = etat.get('paupieres', (self.m.get('visage') or {}).get('paupieres', {}).get('defaut', 'open'))
        for k, v in self.lids.items():
            for gid in (v.values() if isinstance(v, dict) else [v]):
                e = self.el.get(gid)
                if e is None:
                    continue
                if k == choix:
                    e.attrib.pop('display', None)
                else:
                    e.set('display', 'none')
        # bouche + moustache
        mid = etat.get('bouche', self.B['repos'])
        for g in self.mouths:
            e = self.el.get(g)
            if e is None:
                continue
            if g == mid:
                e.attrib.pop('display', None)
            else:
                e.set('display', 'none')
        pb = self.must['par_bouche'].get(mid)
        if pb and self.must['id'] and self.must['id'] in self.el:
            self.el[self.must['id']].set('transform', pb['transform'])
        # sourcils
        for bid in self.brows['ids']:
            dxb, dyb, rot = etat.get('sourcils', {}).get(bid, (0.0, 0.0, 0.0))
            px, py = self.brows['pivots'][bid]
            self.el[bid].set('transform', f'translate({_f(dxb)} {_f(dyb)}) rotate({_f(rot)} {_f(px)} {_f(py)})')
        # regard
        gx, gy = etat.get('iris', (0.0, 0.0))
        ax, ay = self.iris.get('amplitude', [2, 1])
        gx, gy = max(-ax, min(ax, gx)), max(-ay, min(ay, gy))
        for iid in self.iris['ids']:
            self.el[iid].set('transform', f'translate({gx:.2f} {gy:.2f})')
        # chemins déformables
        ch = etat.get('chemins', {})
        for pid, d0 in self.neutral_d.items():
            self.el[pid].set('d', ch.get(pid, d0))

    def svg(self, etat):
        """Contenu SVG (sans balise <svg>) dans le repère du kit, après application de l'état."""
        self.appliquer(etat)
        return ''.join(ET.tostring(c, encoding='unicode') for c in self.root)

    def placer(self, contenu, x, sol, hauteur=None, echelle=None, miroir=False, dy=0.0):
        """Place le personnage : pieds en (x, sol) de la scène. hauteur = taille à l'écran du sommet du bonnet aux
        semelles (ou echelle directe). miroir : regarde de l'autre côté (profil vers la gauche)."""
        s = echelle or (hauteur / max(1.0, self.sol - self.top))
        px, py = self.pieds
        sx = -s if miroir else s
        return (f'<g transform="translate({x:.2f},{sol + dy:.2f}) scale({sx:.4f},{s:.4f}) '
                f'translate({-px:.2f},{-py:.2f})">{contenu}</g>')


class Personnage:
    def __init__(self, dossier, vues, poses=None, cycles=None, seed=0):
        self.vues = {k: Vue(dossier, v) for k, v in vues.items()}
        self.P = json.load(open(os.path.join(dossier, poses))) if poses else {'poses': {}, 'expressions': {}}
        self.cycles = {k: json.load(open(os.path.join(dossier, v))) for k, v in (cycles or {}).items()}
        self.seed = seed
        any_v = next(iter(self.vues.values()))
        self.ph_lat = self.P.get('phonemes') or any_v.m.get('correspondance_phonemes', {})
        self.ph_ar = self.P.get('phonemes_arabe') or any_v.m.get('correspondance_phonemes_arabe', {})

    def echelle(self, hauteur, vue_ref='face'):
        """Échelle commune à toutes les vues : celle qui donne `hauteur` px à la vue de référence (debout).
        À passer en echelle= au placement, pour que Kabour garde la même taille assis, de dos ou de profil."""
        v = self.vues[vue_ref]
        return hauteur / max(1.0, v.sol - v.top)

    def jeu(self, vue, seed=None):
        return Jeu(self, vue, self.seed if seed is None else seed)

    def visemes(self, texte):
        """Suite de bouches (phonèmes) d'un texte en darija (alphabet arabe) ou en latin."""
        out = []
        i = 0
        t = texte.lower()
        while i < len(t):
            ch = t[i]
            if ch.isspace() or ch in '،,.!?؟;:«»"\'-':
                if out and out[-1] != 'MBP':
                    out.append('MBP')
                i += 1
                continue
            if '؀' <= ch <= 'ۿ':
                v = self.ph_ar.get(ch, self.ph_ar.get('_autre', 'etc'))
                if v is not None:
                    out.append(v)
                i += 1
                continue
            two = t[i:i + 2]
            if two in self.ph_lat:
                out.append(self.ph_lat[two]); i += 2
                continue
            out.append(self.ph_lat.get(ch, 'etc'))
            i += 1
        return out


class Jeu:
    """Ligne de temps d'un personnage dans une vue : cycles, poses, expressions, parole, regard."""

    T_POSE, T_EXPR, T_CYCLE = 0.3, 0.2, 0.25

    def __init__(self, perso, vue, seed=0):
        self.p, self.v = perso, perso.vues[vue]
        self.cycles, self.poses, self.exprs, self.paroles, self.regards = [], [], [], [], []
        self.idle = True
        r = random.Random(seed)
        self.phase = r.uniform(0, 6.28)
        self.p_resp, self.p_tete, self.p_bras = r.uniform(2.0, 2.4), r.uniform(2.4, 2.9), r.uniform(2.8, 3.4)
        t, self.blinks = r.uniform(0.6, 1.6), []
        while t < 600:
            self.blinks.append(t)
            t += r.uniform(2.5, 4.0)
        t, self.sacc = r.uniform(0.8, 1.8), []
        while t < 600:
            self.sacc.append((t, r.uniform(-0.6, 0.6), r.uniform(-0.4, 0.4)))
            t += r.uniform(1.4, 3.0)

    # ---------- déclarations
    def marche(self, nom, t0, t1):
        self.cycles.append(dict(nom=nom, t0=t0, t1=t1))
        return self

    def pose(self, nom, t0, t1=None, transition=None):
        self.poses.append(dict(nom=nom, t0=t0, t1=t1 if t1 is not None else 1e9, tr=transition or self.T_POSE))
        return self

    def expression(self, nom, t0):
        self.exprs.append((t0, nom))
        self.exprs.sort()
        return self

    def regard(self, t0, gx, gy):
        self.regards.append((t0, gx, gy))
        self.regards.sort()
        return self

    def parole(self, debut, voix=None, courbe=None, texte=None, fin=None, fps=FPS):
        """Réplique à partir de `debut` : voix = fichier (la courbe de bouche est calculée), ou courbe = liste 0..1
        par image. texte (darija ou latin) = suite de bouches répartie sur les passages parlés."""
        if courbe is None and voix:
            from .voix import courbe_bouche
            courbe = courbe_bouche(voix, fps)
        courbe = courbe or []
        fin = fin if fin is not None else debut + len(courbe) / fps
        seq = self.p.visemes(texte) if texte else None
        idx = None
        if seq:                                   # répartit la suite sur les images où la bouche est ouverte
            actives = [i for i, v in enumerate(courbe) if v > 0.12]
            idx = {}
            sons = [x for x in seq if x != 'MBP'] or seq
            for k, i in enumerate(actives):
                idx[i] = sons[min(len(sons) - 1, int(k * len(sons) / max(1, len(actives))))]
        self.paroles.append(dict(debut=debut, fin=fin, courbe=courbe, seq=idx))
        return self

    # ---------- calcul de l'état
    def _cycle_state(self, t):
        ang, dx, dy, ch = {}, 0.0, 0.0, {}
        for c in self.cycles:
            C = self.p.cycles[c['nom']]
            if t < c['t0'] - 1e-9:
                continue
            te = min(t, c['t1'])
            w = ease((te - c['t0']) / self.T_CYCLE)
            if t > c['t1']:
                w *= 1 - ease((t - c['t1']) / self.T_CYCLE)
            fr = C['frames']
            n = len(fr)
            ph = (te - c['t0']) / C['duree_cycle'] * n
            k0 = int(math.floor(ph))
            a = ph - k0
            f0, f1 = fr[k0 % n], fr[(k0 + 1) % n]
            wrap = (k0 % n) == n - 1
            base = (k0 // n) * C['avance_par_cycle']
            x0 = base + f0.get('corps_dx', 0.0)
            x1 = base + (C['avance_par_cycle'] if wrap else 0.0) + f1.get('corps_dx', 0.0)
            start = fr[0].get('corps_dx', 0.0)
            dx += lerp(x0, x1, a) - start
            dy += lerp(f0.get('corps_dy', 0.0), f1.get('corps_dy', 0.0), a) * w
            for z, js in f0['zones'].items():
                for j, v in js.items():
                    v1 = f1['zones'].get(z, {}).get(j, v)
                    ang[j] = ang.get(j, 0.0) + lerp(v, v1, a) * w
            for pid, d in (f0.get('ourlet') or {}).items():
                d1 = (f1.get('ourlet') or {}).get(pid, d)
                ch[pid] = interp_path(self.v.neutral_d.get(pid, d), interp_path(d, d1, a), w)
        return ang, dx, dy, ch

    def _expr_at(self, t):
        """Expression interpolée : (paupieres, bouche, sourcils, iris, tete_add, humeur_parole)."""
        vue = self.v.nom
        neutre = dict(paupieres=(self.v.m.get('visage') or {}).get('paupieres', {}).get('defaut', 'open'), bouche=None,
                      sourcils={b: (0.0, 0.0, 0.0) for b in self.v.brows['ids']}, iris=(0.0, 0.0), tete=0.0,
                      humeur='neutre', nom=None)

        fam = self.v.m.get('famille_visage', vue)          # ex. assis_face et tailleur → face

        def get(nom):
            if nom is None or nom == 'neutre' or not self.v.face:
                return dict(neutre)
            E = self.p.P['expressions'][nom]
            if fam not in E:
                return dict(neutre)
            e = E[fam]
            humeurs = self.v.B.get('humeurs', ['neutre'])
            hum = E.get('humeur_parole', 'neutre')
            return dict(paupieres=e['paupieres'], bouche=e.get('bouche'),
                        sourcils={b: (s.get('dx', 0.0), s.get('dy', 0.0), s.get('rot', 0.0)) for b, s in e['sourcils'].items()},
                        iris=tuple(e.get('iris', (0, 0))), tete=e.get('tete_additif', 0.0),
                        humeur=hum if hum in humeurs else 'neutre', nom=nom)
        prev, cur, t0 = None, None, 0.0
        for te, nom in self.exprs:
            if te <= t:
                prev, cur, t0 = cur, nom, te
        a, b = get(prev), get(cur)
        k = ease((t - t0) / self.T_EXPR) if cur is not None else 1.0
        out = dict(b) if k >= 0.5 else dict(a)
        out['sourcils'] = {bid: tuple(lerp(x, y, k) for x, y in zip(a['sourcils'].get(bid, (0, 0, 0)), b['sourcils'].get(bid, (0, 0, 0))))
                           for bid in self.v.brows['ids']}
        out['iris'] = tuple(lerp(x, y, k) for x, y in zip(a['iris'], b['iris']))
        out['tete'] = lerp(a['tete'], b['tete'], k)
        return out

    def _bouche_parole(self, t, humeur):
        """Bouche pendant une réplique (None hors parole). Changement au plus toutes les 2 images (pas de scintillement)."""
        if not self.v.face:
            return None
        tq = math.floor(t * FPS / 2) * 2 / FPS
        for p in self.paroles:
            if p['debut'] <= tq < p['fin']:
                i = int(round((tq - p['debut']) * FPS))
                c = p['courbe']
                v = c[i] if i < len(c) else 0.0
                if v < 0.12:
                    ph = 'MBP'
                elif p['seq'] and i in p['seq']:
                    ph = p['seq'][i]
                else:
                    ouv = self.v.B['ouverture']
                    ph = min(ouv, key=lambda k: abs(ouv[k] - v))
                return self.v.B['motif_id'].format(phoneme=ph, humeur=humeur)
        return None

    def etat(self, t):
        ang, dx, dy, ch = self._cycle_state(t)
        walking = any(c['t0'] <= t <= c['t1'] + self.T_CYCLE for c in self.cycles)
        # poses : remplacent leurs zones (transition), oscillations
        for p in self.poses:
            P = self.p.P['poses'][p['nom']]
            if P.get('vue', self.v.nom) != self.v.nom or t < p['t0']:
                continue
            w = ease_in_out((t - p['t0']) / p['tr'])
            if t > p['t1']:
                w *= 1 - ease_in_out((t - p['t1']) / p['tr'])
            if w <= 0:
                continue
            for z in P['zones']:
                for j in self.v.zones.get(z, []):
                    ang[j] = lerp(ang.get(j, 0.0), P['angles'].get(j, 0.0), w)
            for j, o in P.get('oscillation', {}).items():
                ang[j] = ang.get(j, 0.0) + o['amplitude'] * math.sin(2 * math.pi * (t - p['t0']) / o['periode_s']) * w
        e = self._expr_at(t)
        # vie au repos (Bible, section 5)
        sw = math.sin(2 * math.pi * t / self.p_tete + self.phase)
        ang['head'] = ang.get('head', 0.0) + e['tete'] + (1.5 * sw if self.idle else 0.0)
        if self.idle and not walking:
            for z in ('bras_L', 'bras_R', 'bras_near', 'bras_far'):
                for j in self.v.zones.get(z, [])[:1]:
                    sgn = -1 if z in ('bras_R', 'bras_far') else 1
                    ang[j] = ang.get(j, 0.0) + sgn * 1.2 * math.sin(2 * math.pi * t / self.p_bras + self.phase)
        if 'pompom' in self.v.joints:              # le pompon suit la tête avec retard
            h1 = ang['head']
            ang['pompom'] = ang.get('pompom', 0.0) - 0.6 * (h1 - self._head_at(t - 0.18)) + 2 * math.sin(2 * math.pi * t / 1.9 + self.phase)
        resp = 1 + (0.008 * math.sin(2 * math.pi * t / self.p_resp + self.phase) if self.idle else 0.0)
        # paupières : clignement open → half → closed → half → retour
        lids = e['paupieres']
        for b in self.blinks:
            d = t - b
            if 0 <= d < 4 / FPS:
                lids = ('half', 'closed', 'closed', 'half')[int(d * FPS)]
                break
            if b > t:
                break
        # regard : expression + regard demandé + petites saccades
        gx, gy = e['iris']
        for t0, x, y in self.regards:
            if t0 <= t:
                gx, gy = x, y
        sx = sy = 0.0
        for t0, x, y in self.sacc:
            if t0 <= t:
                sx, sy = x, y
            else:
                break
        ax, ay = self.v.iris.get('amplitude', [2, 1])
        gx, gy = gx + sx * ax * 0.5, gy + sy * ay * 0.5
        # bouche
        bp = self._bouche_parole(t, e['humeur'])
        if bp is None:
            bp = e['bouche'] or self.v.B['repos_par_humeur'].get(e['humeur'], self.v.B['repos'])
        for j, a in list(ang.items()):                 # bornes du manifest
            J = self.v.joints.get(j)
            if J and J.get('max', 0) > J.get('min', 0):
                ang[j] = max(J['min'] - 5, min(J['max'] + 5, a))
        return dict(angles=ang, racine=(dx, dy), respiration=resp, paupieres=lids, bouche=bp,
                    sourcils=e['sourcils'], iris=(gx, gy), chemins=ch)

    def _head_at(self, t):
        e = self._expr_at(t)
        h = 0.0
        for p in self.poses:
            P = self.p.P['poses'][p['nom']]
            if P.get('vue', self.v.nom) == self.v.nom and 'head' in P['angles'] and t >= p['t0']:
                w = ease_in_out((t - p['t0']) / p['tr'])
                if t > p['t1']:
                    w *= 1 - ease_in_out((t - p['t1']) / p['tr'])
                h = lerp(h, P['angles']['head'], w)
        return h + e['tete'] + 1.5 * math.sin(2 * math.pi * t / self.p_tete + self.phase)

    def image(self, t):
        return self.v.svg(self.etat(t))

    def placer(self, contenu, x, sol, hauteur=None, echelle=None, miroir=False, dy=0.0):
        return self.v.placer(contenu, x, sol, hauteur, echelle, miroir, dy)

    def position(self, t):
        """Déplacement horizontal du corps (unités du kit) dû aux cycles, pour caler la caméra."""
        return self._cycle_state(t)[1]
