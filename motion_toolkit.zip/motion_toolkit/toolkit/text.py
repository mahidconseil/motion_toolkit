"""Texte → formes vectorielles, correctement mis en forme (Bible, sections 4 et 10).

Le rendu de texte simple de cairosvg détache les lettres arabes et inverse les mots : TOUT texte passe par ici.
L'arabe (darija) utilise Noto Sans Arabic, le latin et les chiffres Roboto. Les segments de directions
différentes (arabe + chiffres latins + nom de marque) sont mis en forme séparément puis ordonnés pour l'affichage.

    svg, (w, h) = text(1180, 120, 'فين كاين شي قهوة قريبة؟', size=30, weight='bold')    # aligné à droite
"""
import os, subprocess, unicodedata

import uharfbuzz as hb
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen

from .svg import esc  # noqa: F401  (réexport pratique)

_ROBOTO = '/usr/share/fonts/truetype/roboto/unhinted/RobotoTTF/'
_NOTO = '/usr/share/fonts/truetype/noto/'
FONT_FILES = {
    ('latin', 'regular'): _ROBOTO + 'Roboto-Regular.ttf',
    ('latin', 'medium'): _ROBOTO + 'Roboto-Medium.ttf',
    ('latin', 'bold'): _ROBOTO + 'Roboto-Bold.ttf',
    ('arabe', 'regular'): _NOTO + 'NotoSansArabic-Regular.ttf',
    ('arabe', 'medium'): _NOTO + 'NotoSansArabic-Bold.ttf',     # pas de Medium installé : Bold
    ('arabe', 'bold'): _NOTO + 'NotoSansArabic-Bold.ttf',
}
_cache = {}


def set_font(script, weight, path):
    """Remplace une police (police fournie par le projet)."""
    FONT_FILES[(script, weight)] = path
    _cache.pop((script, weight), None)


def _font(script, weight):
    key = (script, weight)
    if key not in _cache:
        path = FONT_FILES[key]
        if not os.path.exists(path):
            fam = 'Noto Sans Arabic' if script == 'arabe' else 'Roboto'
            path = subprocess.run(['fc-match', '-f', '%{file}', fam], capture_output=True, text=True).stdout
        face = hb.Face(hb.Blob.from_file_path(path))
        tt = TTFont(path)
        _cache[key] = dict(hb=hb.Font(face), gs=tt.getGlyphSet(), order=tt.getGlyphOrder(), cmap=tt.getBestCmap(),
                           upem=tt['head'].unitsPerEm, asc=tt['hhea'].ascent, desc=tt['hhea'].descent)
    return _cache[key]


# ---------- découpage bidirectionnel simplifié
def _cls(ch):
    b = unicodedata.bidirectional(ch)
    if b in ('R', 'AL'):
        return 'R'
    if b in ('L', 'EN', 'AN'):
        return 'L'
    if b == 'NSM':
        return 'M'
    return 'N'


def is_rtl(text):
    for ch in text:
        k = _cls(ch)
        if k in ('R', 'L'):
            return k == 'R'
    return False


def _runs(text, base_rtl):
    cls = [_cls(ch) for ch in text]
    strong = [c if c in ('R', 'L') else None for c in cls]
    res = []
    for i, c in enumerate(cls):
        if c == 'M':
            res.append(res[-1] if res else ('R' if base_rtl else 'L'))
            continue
        if strong[i]:
            res.append(strong[i]); continue
        prev = next((strong[j] for j in range(i - 1, -1, -1) if strong[j]), None)
        nxt = next((strong[j] for j in range(i + 1, len(cls)) if strong[j]), None)
        res.append(prev if prev and prev == nxt else ('R' if base_rtl else 'L'))
    runs, cur, start = [], res[0] if res else 'L', 0
    for i, d in enumerate(res + ['#']):
        if d != cur:
            runs.append((cur, text[start:i])); cur, start = d, i
    return [r for r in runs if r[1]]


def _split_fonts(txt, rtl, weight):
    """Dans un segment de droite à gauche, les caractères absents de la police arabe (|, symboles)
    passent par la police latine."""
    if not rtl:
        return [('latin', txt)]
    cmap = _font('arabe', weight)['cmap']
    out = []
    for ch in txt:
        sc = 'arabe' if ord(ch) in cmap else 'latin'
        if out and out[-1][0] == sc:
            out[-1] = (sc, out[-1][1] + ch)
        else:
            out.append((sc, ch))
    return out


def _shape_run(txt, rtl, size, weight):
    if rtl:
        pieces = _split_fonts(txt, rtl, weight)
        if len(pieces) > 1:
            parts, x = [], 0.0
            for sc, sub in pieces[::-1]:
                p, w = _shape_run_font(sub, rtl, size, weight, sc)
                parts.append(f'<path transform="translate({x:.2f},0)" d="{" ".join(p)}"/>' if p else '')
                x += w
            return ['__RAW__' + ''.join(parts)], x
    return _shape_run_font(txt, rtl, size, weight, 'arabe' if rtl else 'latin')


def _shape_run_font(txt, rtl, size, weight, script):
    fnt = _font(script, weight)
    buf = hb.Buffer()
    buf.add_str(txt)
    buf.direction = 'rtl' if rtl else 'ltr'
    buf.script = 'Arab' if rtl else 'Latn'
    buf.language = 'ar' if rtl else 'fr'
    hb.shape(fnt['hb'], buf, {})
    s = size / fnt['upem']
    x, parts = 0, []
    for info, pos in zip(buf.glyph_infos, buf.glyph_positions):
        pen = SVGPathPen(fnt['gs'])
        fnt['gs'][fnt['order'][info.codepoint]].draw(
            TransformPen(pen, (s, 0, 0, -s, (x + pos.x_offset) * s, -pos.y_offset * s)))
        d = pen.getCommands()
        if d:
            parts.append(d)
        x += pos.x_advance
    return parts, x * s


def shape(text, size=28, weight='medium'):
    """(chemin d, largeur) d'une ligne, ligne de base à y=0, bord gauche à x=0."""
    base_rtl = is_rtl(text)
    runs = _runs(text, base_rtl)
    if base_rtl:
        runs = runs[::-1]
    x, out = 0.0, []
    for d, txt in runs:
        parts, w = _shape_run(txt, d == 'R', size, weight)
        if parts and parts[0].startswith('__RAW__'):
            out.append(f'<g transform="translate({x:.2f},0)">{parts[0][7:]}</g>')
        elif parts:
            out.append(f'<path transform="translate({x:.2f},0)" d="{" ".join(parts)}"/>')
        x += w
    return ''.join(out), x


def measure(text, size=28, weight='medium'):
    return shape(text, size, weight)[1]


def wrap_lines(text, max_width, size=28, weight='medium'):
    """Coupe un texte en lignes de largeur ≤ max_width (par mots)."""
    words, lines, cur = text.split(), [], ''
    for w in words:
        trial = (cur + ' ' + w).strip()
        if cur and measure(trial, size, weight) > max_width:
            lines.append(cur); cur = w
        else:
            cur = trial
    if cur:
        lines.append(cur)
    return lines


def text(x, y, txt, size=28, color='#202124', weight='medium', align='auto', max_width=None, line_height=1.4,
         opacity=None):
    """Texte en formes vectorielles. align : 'auto' (droite pour l'arabe, gauche sinon), 'left', 'right', 'center'.
    (x, y) = point d'alignement sur la ligne de base de la première ligne. Renvoie (svg, (largeur, hauteur))."""
    lines = wrap_lines(txt, max_width, size, weight) if max_width else [txt]
    rtl = is_rtl(txt)
    al = ('right' if rtl else 'left') if align == 'auto' else align
    out, wmax = [], 0
    for k, ln in enumerate(lines):
        d, w = shape(ln, size, weight)
        wmax = max(wmax, w)
        ox = {'left': x, 'right': x - w, 'center': x - w / 2}[al]
        out.append(f'<g transform="translate({ox:.2f},{y + k * size * line_height:.2f})">{d}</g>')
    op = f' opacity="{opacity:.3f}"' if opacity is not None and opacity < 1 else ''
    return f'<g fill="{color}"{op}>{"".join(out)}</g>', (wmax, size * line_height * len(lines))


def typed(txt, t, t0, cps=18):
    """Portion visible d'un texte écrit lettre par lettre (18 caractères/s, Bible section 5)."""
    n = max(0, int((t - t0) * cps))
    return txt[:n], n >= len(txt)
