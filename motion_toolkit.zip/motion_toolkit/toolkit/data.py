"""Valeurs de la Bible (sections 2, 3 et 5), sans aucune mise en œuvre graphique."""

# Palette Google : 5 teintes × 10 nuances (Bible, section 2)
_SHADES = (50, 100, 200, 300, 400, 500, 600, 700, 800, 900)
_RAMPS = {
    'bleu':  ('#E8F0FE', '#D2E3FC', '#AECBFA', '#8AB4F8', '#669DF6', '#4285F4', '#1A73E8', '#1967D2', '#185ABC', '#174EA6'),
    'rouge': ('#FCE8E6', '#FAD2CF', '#F6AEA9', '#F28B82', '#EE675C', '#EA4335', '#D93025', '#C5221F', '#B31412', '#A50E0E'),
    'jaune': ('#FEF7E0', '#FEEFC3', '#FDE293', '#FDD663', '#FCC934', '#FBBC04', '#F9AB00', '#F29900', '#EA8600', '#E37400'),
    'vert':  ('#E6F4EA', '#CEEAD6', '#A8DAB5', '#81C995', '#5BB974', '#34A853', '#1E8E3E', '#188038', '#137333', '#0D652D'),
    'gris':  ('#F8F9FA', '#F1F3F4', '#E8EAED', '#DADCE0', '#BDC1C6', '#9AA0A6', '#80868B', '#5F6368', '#3C4043', '#202124'),
}
PALETTE = {t: dict(zip(_SHADES, v)) for t, v in _RAMPS.items()}
COULEURS_FRANCHES = ('bleu', 'rouge', 'jaune', 'vert')   # ordre canonique des transitions
WHITE = '#FFFFFF'


def c(teinte, nuance=500):
    """c('bleu', 500) → '#4285F4'."""
    return PALETTE[teinte][nuance]


# Carnations et cheveux (Bible, section 3)
CARNATIONS = {
    'tres_claire': dict(peau='#F6D5B8', ombre='#E8B896'),
    'claire':      dict(peau='#F4A67A', ombre='#D98B62'),
    'moyenne':     dict(peau='#C68863', ombre='#A86E4D'),
    'mate':        dict(peau='#B5715A', ombre='#965A45'),
    'foncee':      dict(peau='#8B4F3A', ombre='#6E3C2B'),
}
CHEVEUX = dict(noir='#202124', brun='#5A3A2E', roux='#C5221F', blond='#F6DFA4')

# Préréglages de dynamisme (Bible, section 5)
PRESETS = {
    'pose':     dict(duree=1.3,  rebond=0.05, plan=(3.5, 5.0)),
    'standard': dict(duree=1.0,  rebond=0.08, plan=(2.5, 3.5)),
    'nerveux':  dict(duree=0.75, rebond=0.10, plan=(1.2, 2.0)),
}

# Repère et formats (Bible, section 2)
DESIGN = (1280, 720)
FORMATS = {'16:9': (1280, 720), '9:16': (720, 1280), '1:1': (1080, 1080)}
SORTIES = {'final': (1920, 1080), 'apercu': (1280, 720), 'vignette': (640, 360)}
FPS = 25
SOL_Y = 0.95            # ligne de sol à 95 % de la hauteur
PARALLAXE = dict(fond=0.2, aplats=0.5, jeu=1.0, premier_plan=1.4)
