"""Valeurs de la Bible (sections 2, 3 et 5), sans aucune mise en œuvre graphique."""

# Palette Google : 5 teintes × 10 nuances (Bible, section 2)
_SHADES = (50, 100, 200, 300, 400, 500, 600, 700, 800, 900)
_RAMPS = {
    'bleu':  ('#E8F0FE', '#D2E3FC', '#AECBFA', '#8AB4F8', '#669DF6', '#4285F4', '#1A73E8', '#1967D2', '#185ABC', '#174EA6'),
    'rouge': ('#FCE8E6', '#FAD2CF', '#F6AEA9', '#F28B82', '#EE675C', '#EA4335', '#D93025', '#C5221F', '#B31412', '#A50E0E'),
    'jaune': ('#FEF7E0', '#FEEFC3', '#FDE293', '#FDD663', '#FCC934', '#FBBC04', '#F9AB00', '#F29900', '#EA8600', '#E37400'),
    'vert':  ('#E6F4EA', '#CEEAD6', '#A8DAB5', '#81C995', '#5BB974', '#34A853', '#1E8E3E', '#188038', '#137333', '#0D652D'),
    'gris':  ('#F8F9FA', '#F1F3F4', '#E8EAED', '#DADCE0', '#BDC1C6', '#9AA0A6', '#80868B', '#5F6368', '#3C4043', '#202124'),
}
PALETTE = {t: dict(zip(_SHADES, v)) for t, v in _RAMPS.items()}
COULEURS_FRANCHES = ('bleu', 'rouge', 'jaune', 'vert')   # ordre canonique des transitions
WHITE = '#FFFFFF'


def c(teinte, nuance=500):
    """c('bleu', 500) → '#4285F4'."""
    return PALETTE[teinte][nuance]


# Carnations et cheveux (Bible, section 3)
CARNATIONS = {
    'tres_claire': dict(peau='#F6D5B8', ombre='#E8B896'),
    'claire':      dict(peau='#F4A67A', ombre='#D98B62'),
    'moyenne':     dict(peau='#C68863', ombre='#A86E4D'),
    'mediterraneen_mat_homme': dict(peau='#DCA27E', ombre='#C2865F'),
    'mediterraneen_mat_femme': dict(peau='#E4AE8C', ombre='#CA916C'),
    'mate':        dict(peau='#B5715A', ombre='#965A45'),   # jugée trop foncée pour un teint méditerranéen
    'foncee':      dict(peau='#8B4F3A', ombre='#6E3C2B'),
}
CHEVEUX = dict(noir='#202124', brun='#5A3A2E', roux='#C5221F', blond='#F6DFA4')

# Préréglages de dynamisme (Bible, section 5)
PRESETS = {
    'pose':     dict(duree=1.3,  rebond=0.05, plan=(3.5, 5.0)),
    'standard': dict(duree=1.0,  rebond=0.08, plan=(2.5, 3.5)),
    'nerveux':  dict(duree=0.75, rebond=0.10, plan=(1.2, 2.0)),
}

# Repère et formats (Bible, section 2)
DESIGN = (1280, 720)
FORMATS = {'16:9': (1280, 720), '9:16': (720, 1280), '1:1': (1080, 1080)}
SORTIES = {'final': (1920, 1080), 'reel': (1080, 1920), 'apercu': (1280, 720), 'apercu_reel': (720, 1280),
           'vignette': (640, 360)}

# Zones sûres du Reel Instagram (proportions de la hauteur et de la largeur, Bible section 2)
ZONES_SURES = {'reel': dict(haut=0.14, bas=0.35, cotes=0.06, coin_bas_droit=0.40)}
REEL_TEXTE_Y = (190, 330)     # bande des textes (repère 720×1280)
REEL_LIMITE_BAS = 830         # visages, logo et appel à l'action au-dessus
COUVERTURE = (3, 4)           # cadre de couverture centré (grille du profil)


def safe_box(fmt='reel', design=None):
    """Rectangle sûr (x0, y0, x1, y1) du repère : hors interface Instagram (haut, bas, côtés)."""
    w, h = design or FORMATS['9:16']
    z = ZONES_SURES[fmt]
    return (w * z['cotes'], h * z['haut'], w * (1 - z['cotes']), h * (1 - z['bas']))


def cover_box(design=None):
    """Cadre 3:4 centré (x0, y0, x1, y1) de l'image de couverture."""
    w, h = design or FORMATS['9:16']
    ch = w * COUVERTURE[1] / COUVERTURE[0]
    return (0, (h - ch) / 2, w, (h + ch) / 2)
FPS = 25
SOL_Y = 0.95            # ligne de sol à 95 % de la hauteur
PARALLAXE = dict(fond=0.2, aplats=0.5, jeu=1.0, premier_plan=1.4)
