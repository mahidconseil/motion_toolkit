"""Primitives de composition entre deux plans (Bible, sections 7 et 10). Aucune transition toute faite :
chaque transition du catalogue est construite pour le film avec ces briques.

    svg = over(plan_a, mask(plan_b, circle_shape(640, 360, r)))          # révélation circulaire
    svg = offset(plan_a, -1280 * k) + offset(plan_b, 1280 * (1 - k))      # slide
Toutes les formes prennent la taille du repère (size=(largeur, hauteur)) : 1280×720 par défaut, 720×1280 en Reel.
"""
import math

from .svg import uid
from .data import DESIGN

W, H = DESIGN


def mask(content, shape_d):
    """Ne montre `content` qu'à l'intérieur du chemin `shape_d` (masque net, sans flou)."""
    i = uid('clip')
    return f'<clipPath id="{i}"><path d="{shape_d}"/></clipPath><g clip-path="url(#{i})">{content}</g>'


def over(*layers):
    """Empile des couches (la dernière au-dessus)."""
    return ''.join(layers)


def offset(content, dx=0.0, dy=0.0):
    return f'<g transform="translate({dx:.2f},{dy:.2f})">{content}</g>'


def opacity(content, a):
    a = max(0.0, min(1.0, a))
    return content if a >= 1 else (f'<g opacity="{a:.3f}">{content}</g>' if a > 0 else '')


def fill_screen(color, a=1.0, size=None):
    w, h = size or (W, H)
    return f'<rect x="-50" y="-50" width="{w + 100}" height="{h + 100}" fill="{color}" opacity="{a:.3f}"/>'


# ---------- formes de masque (chemins)
def circle_shape(cx, cy, r):
    r = max(0.0, r)
    return f'M{cx - r:.2f},{cy:.2f} a{r:.2f},{r:.2f} 0 1,0 {2 * r:.2f},0 a{r:.2f},{r:.2f} 0 1,0 {-2 * r:.2f},0 Z'


def rect_shape(x, y, w, h):
    return f'M{x:.2f},{y:.2f} h{w:.2f} v{h:.2f} h{-w:.2f} Z'


def band_shape(pos, width, angle_deg=20.0, size=None):
    """Bande inclinée qui traverse l'écran ; pos = abscisse de son bord gauche au milieu de l'écran."""
    _, h = size or (W, H)
    sl = h / 2 * math.tan(math.radians(angle_deg))
    x0, x1 = pos, pos + width
    return (f'M{x0 + sl:.2f},-10 L{x1 + sl:.2f},-10 L{x1 - sl:.2f},{h + 10} L{x0 - sl:.2f},{h + 10} Z')


def half_plane_shape(pos, angle_deg=20.0, side='right', size=None):
    """Tout l'écran d'un côté d'une droite inclinée (volet)."""
    w, h = size or (W, H)
    sl = h / 2 * math.tan(math.radians(angle_deg))
    if side == 'right':
        return f'M{pos + sl:.2f},-10 L{w + 2000},-10 L{w + 2000},{h + 10} L{pos - sl:.2f},{h + 10} Z'
    return f'M-2000,-10 L{pos + sl:.2f},-10 L{pos - sl:.2f},{h + 10} L-2000,{h + 10} Z'


def max_radius(cx, cy, size=None):
    """Rayon qui couvre tout l'écran depuis (cx, cy)."""
    w, h = size or (W, H)
    return max(math.hypot(cx - x, cy - y) for x in (0, w) for y in (0, h)) + 2


def speed_lines(k, y_list, length=260, color='#E8EAED', width=3, direction=1, size=None):
    """Traînées de vitesse (filé rapide) : intensité k 0..1, direction ±1."""
    if k <= 0:
        return ''
    w, _ = size or (W, H)
    out = []
    for i, y in enumerate(y_list):
        x = (w / 2) + direction * (i * 97 % 400 - 200)
        L = length * k
        out.append(f'<line x1="{x - L / 2:.1f}" y1="{y}" x2="{x + L / 2:.1f}" y2="{y}" stroke="{color}" '
                   f'stroke-width="{width}" stroke-linecap="round" opacity="{min(1, k * 1.5):.2f}"/>')
    return ''.join(out)
