# Kits personnage

Ce dossier reçoit les fichiers de calibration des kits (`<nom>.json`), un par kit validé.
Procédure (Bible, section 10) : `toolkit.kits.unzip_kit` → `convert` → `load_shapes` → `inventory`
(planche quadrillée, à faire valider) → repérage des zones → `colors_report` / `nearest_palette`
→ calibration (schéma dans `toolkit/kits.py`) → `save_kit`. Le personnage s'anime ensuite avec `toolkit.rig.Character`.
